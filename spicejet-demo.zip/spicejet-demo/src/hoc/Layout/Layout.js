import React, {Component} from 'react'
import Auxiliary from '../Auxiliary/Auxiliary'
import Toolbar from '../../component/Navigation/Toolbar/Toolbar'
import Footbar from '../../component/Navigation/Footbar/Footbar'

class Layout extends Component{
    render(){
        return(
            <Auxiliary>
                <Toolbar />
                <main>
                    {this.props.children}
                </main>
                <Footbar />
            </Auxiliary>
        )
    }
}

export default Layout