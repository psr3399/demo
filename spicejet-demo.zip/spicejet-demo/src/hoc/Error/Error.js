import React from 'react'

export default function Error(props) {
    console.log(props.show)
    return (
        props.show ?
        <div className="alert alert-danger alert-dismissible fade show" role="alert" style={{zIndex:'500'}} onClick={props.closeback}>
            <span><strong>Error:</strong>{props.msg}</span>
            {/* <button type="button" className="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button> */}
        </div>
        : null
    )
}
