module.exports = {
  phoneExistUrl:
    "http://122.15.2.126/pass/api/Flightpass/IsTravellerExist?Mobile=",
  addTravellerUrl:
    "http://122.15.2.126/pass/api/Flightpass/CreateFlightpass_Agent",
  passAmountUrl: "http://122.15.2.126/pass/api/Dashboard/GetAmount",
  // passCountUrl:"http://122.15.2.126/pass/api/Dashboard/GetAmount",
  getAccountBalUrl:
    "http://122.15.2.126/pass/api/AgentPayment/GetAccountBalance?agentName=",
  getAgAccountIdUrl: "http://122.15.2.126/pass/api/Customer/getAGAccountID",
  agentPaymentResponseUrl:
    "http://122.15.2.126/pass/api/AgentPayment/AGPaymentResponse",
  insertSubagentUrl:
    "http://122.15.2.126/pass/api/AgentPayment/InsertSubAgentTransaction?agentName=",
  returnUrl: "http://localhost:3000/JusPayResponse",
  //returnUrl: "http://10.218.31.215:8000/JusPayResponse",
  getBuyPassAmount:
    "http://122.15.2.126/PublicFlightPassAPI/api/Dashboard/GetAmount",
  insertCustomerTravelDocUrl:
    "http://122.15.2.126/pass/api/Customer/InsertCustomerTravelDocumentsToNavitaire",
  returnUrlBuyPass: "http://localhost:3000/JusPayResponse",
  //returnUrlBuyPass: "http://10.218.31.215:8000/JusPayResponse",
  loadPassHistoryUrl:
    "http://122.15.2.126/Pass/api/FlightPass/getMemberData?id=",
  createFlightPassUrl:
    "http://122.15.2.126/pass/api/FlightPass/CreateFlightpass",
  isUserExistUrl: "http://122.15.2.126/pass/api/Customer/IsUserExists",
  isEmailExistUrl: "http://122.15.2.126/pass/api/Customer/IsEmailIdExists",
  validateOtpUrl: "http://122.15.2.126/pass/api/Customer/ValidateOTP",
  registerUserUrl:
    "http://122.15.2.126/pass/api/Registration/CreateAccountForSpiceclub",
  sendOtpscUrl: "http://122.15.2.126/pass/api/Customer/SendOTPSC",
  resendOtpscUrl: "http://122.15.2.126/pass/api/Customer/ReSendOTPSC",
  memberDetailsUrl: "http://122.15.2.126/pass/api/Customer/Login",
  memberTableUrl:
    "http://122.15.2.126/pass/api/FlightPass/getMemberDashboard?mobileNumber=&loginID=919985266348",
  agentDetailsUrl: "http://122.15.2.126/pass/api/Customer/Login",
  agentTableUrl:
    "http://122.15.2.126/pass/api/FlightPass/getMemberDashboard?mobileNumber=&loginID=919985266348",
  initTravellerTableUrl:
    "http://122.15.2.126/pass/api/FlightPass/getAgentid?id",
  initAgentTable: "http://122.15.2.126/pass/api/FlightPass/getAgentData?id=",
};
