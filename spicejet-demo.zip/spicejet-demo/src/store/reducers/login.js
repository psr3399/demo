import * as actionTypes from "../actions/actionTypes";

const initialState = {
  userData: {},
  isLoggedIn: false,
  isLoggedInAgent: false,
  loading: false,
  tableData: {},
  selectedPassenger: {},
  personData: {},
  userTableData: [],
  loadingAgentTable:false
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.SET_DETAILS:
      return {
        ...state,
        userData: action.data,
        isLoggedIn: action.isLoggedIn,
        loading: false,
      };
    case actionTypes.SET_AGENT_DETAILS:
      return {
        ...state,
        userData: action.data,
        isLoggedInAgent: action.isLoggedInAgent,
        loading: false,
      };
    case actionTypes.ON_LOGIN_START:
      return {
        ...state,
        loading: true,
      };
    case actionTypes.ON_LOGIN_FAIL:
      return {
        ...state,
        loading: false,
      };
    case actionTypes.AUTH:
      return {
        ...state,
        isLoggedIn: action.isLoggedIn,
      };
    case actionTypes.AUTH_LOGOUT:
      return {
        ...state,
        UserData: null,
        isLoggedIn: false,
      };
    case actionTypes.SET_TABLE:
      return {
        ...state,
        tableData: action.tableData,
      };
    case actionTypes.SET_PASSENGER_DETAILS:
      return {
        ...state,
        selectedPassenger: action.selectedPassenger,
      };
    case actionTypes.SET_TRAVELLER_TABLE:
      return {
        ...state,
        personData: action.personData,
      };
    case actionTypes.SET_AGENT_TABLE:
      console.log("snew data", action.userTableData);
      return {
        ...state,
        userTableData: action.userTableData,
        loadingAgentTable:false
      };
    case actionTypes.LOADING_AGENT_TABLE:
      return {
        ...state,
        loadingAgentTable:true,
      };
    default:
      return state;
  }
};

export default reducer;
