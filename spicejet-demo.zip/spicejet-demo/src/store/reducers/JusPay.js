import * as actionTypes from "../actions/actionTypes";

const initialState = {
  payload: {},
  baseOrder: {},
  signature: "",
  PassType: "",
  PassValidity: "",
  PassCount: "",
  PassAmount: "",
  AmountPerPass: "",
  SelectedPax: {},
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.JUSPAY_REQUEST:
      return {
        ...state,
        payload: action.payload,
        baseOrder: action.baseOrder,
        signature: action.signature,
      };
    case actionTypes.ADD_PAY_DETAILS:
      return {
        ...state,
        PassType: action.PassType,
        PassValidity: action.PassValidity,
        PassCount: action.PassCount,
        PassAmount: action.PassAmount,
        AmountPerPass: action.AmountPerPass,
        SelectedPax: action.SelectedPax,
      };
    // case actionTypes.JUSPAY_RESPONSE:
    //   return {
    //     ...state,
    //     response: action.response,
    //   };
    default:
      return state;
  }
};

export default reducer;
