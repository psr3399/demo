import { combineReducers } from "redux";
import login from "./login";
import juspay from "./JusPay";

const RootReducer = combineReducers({
  login,
  juspay,
});

export default RootReducer;
