import * as actionTypes from "./actionTypes";
import axios from "axios";
import * as allUrls from '../../Constants/Constants'


export const setDetails = (data, isLoggedIn) => {
  return {
    type: actionTypes.SET_DETAILS,
    data: data,
    isLoggedIn: isLoggedIn,
  };
};

export const setAgentDetails = (data, isLoggedInAgent) => {
  return {
    type: actionTypes.SET_AGENT_DETAILS,
    data: data,
    isLoggedInAgent: isLoggedInAgent,
  };
};
export const onLoginStart = () => {
  return {
    type: actionTypes.ON_LOGIN_START,
  };
};

export const loadingAgentTable = () => {
  return {
    type: actionTypes.LOADING_AGENT_TABLE,
  };
};

export const auth = (isLoggedIn) => {
  return {
    type: actionTypes.AUTH,
    isLoggedIn: isLoggedIn,
  };
};

export const onLoginFail = () => {
  return {
    type: actionTypes.ON_LOGIN_FAIL,
  };
};

export const logout = () => {
  return {
    type: actionTypes.AUTH_LOGOUT,
  };
};

export const checkAuthTimeout = (expirationTime) => {
  return (dispatch) => {
    setTimeout(() => {
      dispatch(logout());
    }, expirationTime);
  };
};

export const setTable = (tableData) => {
  return {
    type: actionTypes.SET_TABLE,
    tableData: tableData,
  };
};

export const setPassengerDetails = (selectedPassenger) => {
  console.log("selectedPassenger", selectedPassenger);
  return {
    type: actionTypes.SET_PASSENGER_DETAILS,
    selectedPassenger: selectedPassenger,
  };
};

export const setTravellerTable = (personData) => {
  console.log("inside settravellertable", personData);
  return {
    type: actionTypes.SET_TRAVELLER_TABLE,
    personData: personData,
  };
};

export const setAgentTable = (userTableData) => {
  console.log("triggerd agent table");
  return {
    type: actionTypes.SET_AGENT_TABLE,
    userTableData: userTableData,
  };
};
// export const onPostLogin = (MobileOrEmail,Password,isLoggedIn) => {
//     return dispatch => {
//         dispatch(onLoginStart())
//         const authData={
//             DomainCode:"domainCode",
//             MobileOrEmail:MobileOrEmail,
//             Password:Password,
//         }
//         // let data= this.state
//         axios.post('http://122.15.2.126/PublicFlightPassAPI/api/Customer/Login',authData)
//             .then(res => {
//                 dispatch(setDetails(res.data.ResponseObject,isLoggedIn=!isLoggedIn))

//             })
//             // .catch(alert('err'))
//             .catch(err => console.log(err))
//     }
// }

export const onPostLogin = (
  DomainCode,
  MobileOrEmail,
  Password,
  isLoggedIn
) => {
  return async (dispatch) => {
    dispatch(onLoginStart());
    const authData = {
      DomainCode: DomainCode,
      MobileOrEmail: MobileOrEmail,
      Password: Password,
    };
    const detailsUrl = allUrls.memberDetailsUrl;
    const TableUrl =
      allUrls.memberTableUrl;

    try {
      const res = await axios.post(detailsUrl, authData);
      if (Object.keys(res.data.ResponseObject).length) {
        isLoggedIn = true;
        axios.get(TableUrl).then((response) => {
          //  console.log("I am in action:"+response.data)
          dispatch(setTable(response.data));
        });
      }
      dispatch(setDetails(res.data.ResponseObject, isLoggedIn));
      dispatch(checkAuthTimeout(9000000));
    } catch (err) {
      alert("Incorrect SpiceClub Member ID / Password");
      dispatch(onLoginFail());
    }
  };
};
export const onPostAgentLogin = (
  DomainCode,
  AgentId,
  Password,
  isLoggedInAgent
) => {
  return async (dispatch) => {
    dispatch(onLoginStart());
    const authData = {
      DomainCode: DomainCode,
      MobileOrEmail: AgentId,
      Password: Password,
    };
    const detailsUrl = allUrls.agentDetailsUrl;
    const TableUrl =
      allUrls.agentTableUrl;

    try {
      const res = await axios.post(detailsUrl, authData);
      if (Object.keys(res.data.ResponseObject).length) {
        isLoggedInAgent = true;
        // axios.get(TableUrl).then((response) => {
        //   //  console.log("I am in action:"+response.data)
        //   dispatch(setTable(response.data));
        // });
      }
      dispatch(setAgentDetails(res.data.ResponseObject, isLoggedInAgent));
      dispatch(checkAuthTimeout(9000000));
    } catch (err) {
      alert("Incorrect Agent ID / Password");
      dispatch(onLoginFail());
    }
  };
};

export const initTravellerTable = (userNameData) => {
  return async (dispatch) => {
    var url =
      allUrls.initTravellerTableUrl + userNameData;

    try {
      console.log("in try method");
      axios.get(url).then((res) => {
        console.log("res.data", res.data);
        if (
          res.data != null &&
          JSON.parse(res.data).CustomersList.Customer != null &&
          JSON.parse(res.data).CustomersList.Customer.length > 0
        ) {
          const personData = JSON.parse(res.data).CustomersList.Customer;
          console.log("this is persondata", personData);
          dispatch(setTravellerTable(personData));
        }
      });
    } catch (err) {
      alert("error in setting table");
    }
  };
};

export const initAgentTable = (userNameData) => {
  return async (dispatch) => {
    dispatch(loadingAgentTable());
    var url =
      allUrls.initAgentTable + userNameData;

    try {
      console.log("triggering init table");
      const res = await axios.get(url);
      console.log('after await init table')
      dispatch(setAgentTable(res.data));
    } catch (err) {
      alert("error in setting table");
    }
  };
};
// axios.all([
//   axios.get('https://api.github.com/users/mapbox'),
//   axios.get('https://api.github.com/users/phantomjs')
// ])
// .then(responseArr => {
//   //this will be executed only when all requests are complete
//   console.log('Date created: ', responseArr[0].data.created_at);
//   console.log('Date created: ', responseArr[1].data.created_at);
// });
