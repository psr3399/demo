import * as actionTypes from "./actionTypes";
//import axios from 'axios'

export const setRequestData = (payload, baseOrder, signature) => {
  return {
    type: actionTypes.JUSPAY_REQUEST,
    payload: payload,
    baseOrder: baseOrder,
    signature: signature,
  };
};
export const onJusPayRequest = (payload, baseOrder, signature) => {
  return (dispatch) => {
    try {
      dispatch(setRequestData(payload, baseOrder, signature));
    } catch (err) {
      console.log("onJusPayRequest - err", err);
    }
  };
};

export const onJusPayResponse = (payload, baseOrder, signature) => {
  return (dispatch) => {
    try {
      // dispatch(setRequestData(payload, baseOrder, signature));
    } catch (err) {
      console.log("onJusPayResponse - err", err);
    }
  };
};

export const addPayDetails = (
  PassType,
  PassValidity,
  PassCount,
  PassAmount,
  AmountPerPass,
  SelectedPax
) => {
  console.log(
    "inside jus action",
    PassType,
    PassValidity,
    PassCount,
    PassAmount,
    AmountPerPass,
    SelectedPax
  );
  return {
    type: actionTypes.ADD_PAY_DETAILS,
    PassType: PassType,
    PassValidity: PassValidity,
    PassCount: PassCount,
    PassAmount: PassAmount,
    AmountPerPass: AmountPerPass,
    SelectedPax: SelectedPax,
  };
};
