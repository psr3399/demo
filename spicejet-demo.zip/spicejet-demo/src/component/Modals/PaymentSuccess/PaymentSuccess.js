import React, { Component } from 'react';
import './PaymentSuccess.css';

class PaymentSuccess extends Component {
  // constructor(props){
    // super(props);
    // this.state = {};
  // }

  // componentWillMount(){}
  // componentDidMount(){}
  // componentWillUnmount(){}

  // componentWillReceiveProps(){}
  // shouldComponentUpdate(){}
  // componentWillUpdate(){}
  // componentDidUpdate(){}

  render() {
    return (
      <>
          <div className="modal fade" id="ignismyModal" role="dialog">
            <div className="modal-dialog text-center">
                <div className="modal-content">
                    <div className="modal-header">
                      <span className="imgalnmt"><img src="images/tickmark.png" className="img-fluid" style="width: 75%;" alt="" /></span>
                        <button type="button" className="close" data-dismiss="modal" aria-label=""><span>×</span></button>
                     </div>
					
                    <div className="modal-body">
                       
						<div className="thank-you-pop">
							
							<h2 className="redtxt mb-4 mt-2">Congratulations!</h2>
							<p>Your have successfully purchased flight pass</p>
							<h3 className="cupon-pop">You will receive an email shortly with details on your registerd e-mail address</h3>
							<div className="d-flex">
                <div className="p-2 flex-fill">
                  <p><strong> flight Pass ID </strong></p>
                  <p>SGSH6123</p>
                </div>
                <div className="p-2 flex-fill">
                  <p><strong>Pass Type </strong></p>
                  <p>Short Haul</p>
                </div><div className="p-2 flex-fill">
                  <p><strong>Pass Count / Avalilable </strong></p>
                  <p>10/10</p>
                </div><div className="p-2 flex-fill">
                  <p><strong>VALIDITY </strong></p>
                  <p>6 Months</p>
                </div><div className="p-2 flex-fill">
                  <p><strong>AMOUNT </strong></p>
                  <p>72,000</p>
                </div><div className="p-2 flex-fill">
                  <p><strong>STATUS </strong></p>
                  <p>Active</p>
                </div><div className="p-2 flex-fill">
                  <p><strong>VALID TILL </strong></p>
                  <p>30<sup>th</sup> June 2020</p>
                </div>
              </div>
 						</div>
                         
                    </div>
					
                </div>
            </div>
        </div>

      </>
    );
  }
}

export default PaymentSuccess;