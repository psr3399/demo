import React from 'react'
import Logo from '../../../assets/images/fplogo.png'

const logo = (props) => {
    return (
        <div>
            <img src={Logo} alt="no" style={{height:'65px',width:'300px'}}/>
        </div>
    )
}

export default logo