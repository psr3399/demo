import React from "react";
import Logo from "../../../assets/images/fplogo.png";
import { connect } from "react-redux";
import * as loginActions from "../../../store/actions/index";
import { Link } from "react-router-dom";

const toolbar = (props) => {
  console.log("from toolbar is log", props.isLoggedIn);
 
  return (
    <header>
      <nav className="navbar shadow-sm navbar-expand-lg navbar-default bg-default static-top">
        <div className="container">
          <a className="navbar-brand" href="/">
            <img src={Logo} alt="no" className="img-fluid" alt="" />
          </a>
          <button
            className="navbar-toggler"
            type="button"
            data-toggle="collapse"
            data-target="#navbarResponsive"
            aria-controls="navbarResponsive"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarResponsive">
            <ul className="navbar-nav ml-auto">
              {props.isLoggedIn ? (
                <li className="nav-item active">
                  <Link className="nav-link" to="/flightpass">
                    My Account
                  </Link>
                </li>
              ) : (
                ""
              )}
              {props.isLoggedInAgent ? (
                <li className="nav-item active">
                  <Link className="nav-link" to="/agentDashboard">
                    My Account
                  </Link>
                </li>
              ) : (
                ""
              )}

              <li className="nav-item">
                <a className="nav-link" onClick={props.onLogout} href="/">
                  {props.isLoggedIn || props.isLoggedInAgent
                    ? "LOGOUT"
                    : "LOGIN"}
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>
  );
};

const mapStateToProps = (state) => {
  return {
    isLoggedIn: state.login.isLoggedIn,
    isLoggedInAgent: state.login.isLoggedInAgent,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    //as href sends to login page this function is to null the login details
    onLogout: () => dispatch(loginActions.logout()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(toolbar);
