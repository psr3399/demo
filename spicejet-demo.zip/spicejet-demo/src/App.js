import React from "react";
// import './App.css';
import { Route, Switch } from "react-router-dom";
import Layout from "./hoc/Layout/Layout";
import FlightPass from "./containers/FlightPass/FlightPass";
import AgentDashboard from "./containers/AgentDashboard/AgentDashboard";
import AgentPay from "./containers/AgentPay/AgentPay";
import Registration from "./containers/Registration/Registration";
import SpiceLogin from "./containers/SpiceLogin/SpiceLogin";
import BuyPass from "./containers/FlightPass/BuyPass/BuyPass";
import JusPayRequest from "./containers/Payments/JusPayRequest";
import JusPayResponse from "./containers/Payments/JusPayResponse";
import ThankYou from "./containers/Payments/ThankYou";
import RegistrationSuccessful from "./containers/Registration/RegistrationSuccessful";
import FailedTransaction from "./containers/Payments/FailedTransaction";
function App() {
 
  
  return (
    <div>
      <Layout>
        <Switch>
          <Route exact path="/">
            <SpiceLogin />
          </Route>
          {/* <Route exact path="/login">
            <SpiceLogin />
          </Route> */}
          <Route exact path="/flightpass">
            <FlightPass />
          </Route>
          <Route path="/AgentDashboard">
            <AgentDashboard />
          </Route>
          <Route path="/AgentPay">
            <AgentPay />
          </Route>
          <Route path="/Registration">
            <Registration />
          </Route>
          <Route path="/RegistrationSuccess">
            <RegistrationSuccessful />
          </Route>
          <Route path="/BuyPass">
            <BuyPass />
          </Route>
          <Route path="/JusPayRequest">
            <JusPayRequest />
          </Route>
          <Route path="/JusPayResponse">
            <JusPayResponse />
          </Route>
          <Route path="/ThankYou">
            <ThankYou />
          </Route>
          <Route path="/FailedTransaction">
            <FailedTransaction />
          </Route>
        </Switch>
      </Layout>
    </div>
  );
}

export default App;
