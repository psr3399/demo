import {
  withFormik,
  FormikProps,
  Formik,
  Field,
  Form,
  ErrorMessage,
} from "formik";
import { withRouter } from "react-router";
import * as Yup from "yup";
import PhoneInput from "react-phone-input-2";
import "bootstrap/dist/css/bootstrap.min.css";
import "react-phone-input-2/lib/style.css";
import { button, Modal } from "react-bootstrap";
import moment from "moment";
// import Error from '../../hoc/Error/Error'
import React, { Component } from "react";
import axios from "axios";
// import { Otp } from "react-otp-timer";
import Timer from "../Registration/Timer";
import * as allUrls from "../../Constants/Constants";

const initialValues = {
  title: "Mr",
  firstName: "",
  lastName: "",
  id: "PAN",
  idnum: "",
  date: new Date(),
  mobile: "",
  email: "",
  pass1: "",
  pass2: "",
  terms: false,
};

const validationSchema = Yup.object({
  firstName: Yup.string()
    .strict()
    .max(15, "Must be 15 characters or less")
    .required("First Name should not be empty"),

  lastName: Yup.string()
    .max(20, "Must be 20 characters or less")
    .required("Last Name should not be empty"),
  id: Yup.string(),
  idnum: Yup.string().when("id", {
    is: "PAN",
    then: Yup.string()
      .matches("[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}", "invalid pan")
      .required("Plase provide PAN/Passport"),
    otherwise: Yup.string()
      .matches("[0-9]", "Invalid passport")
      .required("Plase provide PAN/Passport"),
  }),
  // .matches('[A-Z]{5}[0-9]{4}[A-Z]{1}','invalid pan')
  // .required('Plase provide PAN/Passport'),
  date: Yup.string()
    .required("Please fill DOB")
    .test("fine", "Age should be greater then 18 years", (value) => {
      //   if (value.length < 10) {
      let today = new Date();
      var birthDate = new Date(value);
      var age = today.getFullYear() - birthDate.getFullYear();
      console.log("birthDate.getFullYear()" + birthDate.getFullYear());
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 18) {
        return false;
      } else if (birthDate.getFullYear().length > 4) {
        return false;
      } else {
        return true;
      }

      //   } else {
      //     return false;
      //   }
    }),

  mobile: Yup.string()
    .min(10, "Mobile No. too short")
    .required("Mobile No. required")
    .test("fine", "Mobile No. Exist! PLEASE LOGIN", (value) => {
      const isUerExists = allUrls.isUserExistUrl;
      console.log(value);
      const isUserExistData = {
        mobilenumber: value,
        emailaddress: "",
        CardHolderName: "",
      };
      return axios.post(isUerExists, isUserExistData).then((res) => {
        console.log(res);
        if (
          res.data === "FAILED"
          //         "Account is already registered with the given email address. Please provide another email address to proceed with Registration."
        ) {
          return false;
        } else {
          console.log("didnt matched");
          return true;
        }
      });
    }),
  email: Yup.string()
    .email("Invalid email address")
    .required("Email should not be empty")
    .test("fine", "Email exist! PLEASE LOGIN", (value) => {
      // if(value.length<10){
      //     return true
      // }else{
      //     return false
      // }

      const isEmailExist = allUrls.isEmailExistUrl;
      const isEmailExistData = {
        emailaddress: value,
      };
      return axios.post(isEmailExist, isEmailExistData).then((res) => {
        if (
          res.data === "FAILED"
          // "Account is already registered with the given email address. Please provide another email address to proceed with Registration."
        ) {
          return false;
        } else {
          return true;
        }
      });
    }),
  pass1: Yup.string()
    // atleast one digit regex
    .matches(
      "(?=.*[0-9])(?=.*[a-z])(?=.*[@&#$%])(?=.*[A-Z])([a-zA-Z0-9@&#$%]{8,})",
      "Invalid format"
    )
    .required("Password Required"),
  pass2: Yup.string()
    .oneOf([Yup.ref("pass1")], "Password not same")
    .required("Password Required"),
  terms: Yup.bool().oneOf(
    [true],
    "Please agree Terms and Conditions to continue."
  ),
});

class Registration extends Component {
  constructor() {
    super();

    this.state = {
      show: false,
      userOtp: "",
      setValues: {},
      isOtpValid: false,
      otpError: "",
      minutes: "",
      seconds: "",
      buttonDisable: false,
      maxdate: moment().add(-18, "year").format("YYYY-MM-DD"),
      mindate: moment().add(-100, "year").format("YYYY-MM-DD"),
      tncshow: false,
    };
  }

  tncModal() {
    this.setState({ tncshow: true });
  }
  closetnc = () => {
    this.setState({ tncshow: false });
  };
  onOtpChange = (event) => {
    this.setState({ userOtp: event.target.value });
  };

  checkValidtyHandler = () => {
    console.log(this.state.setValues.mobile.substring(0, 2));
    const ValidateOTP = allUrls.validateOtpUrl;
    const ValidateOTPData = {
      mobilenumber: this.state.setValues.mobile,
      OTPString: this.state.userOtp,
    };
    console.log("validate data", ValidateOTPData);
    axios.post(ValidateOTP, ValidateOTPData).then((res) => {
      console.log(res.data);
      if (res.data === "SUCCESS") {
        const showStore = !this.state.show;
        this.setState({ show: showStore });
        //do a history.push to login
        //how to show registration done message
        debugger;
        var DOBChange = moment(this.state.setValues.date).format("DD/MM/YYYY"); // moment(this.state.setValues.date, "DD-MM-YYYY");
        const registrationUrl = allUrls.registerUserUrl;
        const registrationData = {
          title: this.state.setValues.title,
          firstname: this.state.setValues.firstName,
          lastname: this.state.setValues.lastName,
          mobilenumber: this.state.setValues.mobile,
          countrycode:
            this.state.setValues.mobile.substring(0, 2) == "91"
              ? "IN"
              : this.state.setValues.mobile.substring(0, 2),
          emailid: this.state.setValues.email,
          DOB: DOBChange,
          Password: this.state.setValues.pass1,
          SubscribeType: 1,
          Platformtype: "FlightPassApp",
          LoggedBy: null,
          LoggedByRole: null,
          Channel: "MobileAPI",
          Pancardnumber: this.state.setValues.idnum,
          IsAccountValidated: true,
          IsLateralEntry: false,
          LateralCode: null,
          EmailType: "2",
        };
        console.log(registrationData);
        axios.post(registrationUrl, registrationData).then((res) => {
          console.log("registrationData" + res.data);
          this.setState({ show: showStore });
          this.props.history.push({
            pathname: "/RegistrationSuccess",
          });
        });
      } else {
        this.setState({
          isOtpValid: true,
          otpError: "*Please enter valid OTP",
        });
      }
    });
  };

  callbackFunction = (min, sec) => {
    // this.setState({
    //   minutes: min,
    //   seconds:sec
    // })
    console.log("min and sec arrived", min, sec);
    if (this.state.show) {
      if (min == 0 && sec == 0) {
        this.setState({ buttonDisable: true });
      } else {
        this.setState({ buttonDisable: false });
      }
    }
  };

  componentDidUpdate = () => {
    // this.buttonDisableHandler()
  };

  buttonDisableHandler = () => {
    // let timeout = setTimeout(() => {
    //   console.log('inside interval')
    //   if(this.state.show){
    //     if(this.state.minutes == 0 && this.state.seconds == 0){
    //       this.setState({buttonDisable:true,otpError:'Your OTP has expired'})
    //     }else{
    //       this.setState({buttonDisable:false})
    //     }
    //   }
    //   timeout =setTimeout(this.buttonDisableHandler,5000)
    // }, 5000);
  };

  render() {
    console.log(this.state.setValues);
    return (
      <Formik
        initialValues={initialValues}
        validationSchema={validationSchema}
        onSubmit={(values) => {
          const SendOTPSC = allUrls.sendOtpscUrl;
          const SendOTPSCData = {
            mobilenumber: values.mobile,
            emailaddress: "",
            CardHolderName: "",
          };

          axios.post(SendOTPSC, SendOTPSCData);
          // .then(res=>console.log(res.data))
          console.log("post request sent");
          const showStore = !this.state.show;
          this.setState({ show: showStore, setValues: values });
          this.buttonDisableHandler();
        }}
      >
        {(formik) => (
          <div className="container mb-5">
            <div className="registrationPage mainBackground mainBanner">
              <div className="registrationWrapper">
                <div className="introducingbackground">
                  <div className="introducingCol">
                    <h3 className="introducingTitle">Introducing</h3>
                    <div className="spiceClubLogo"></div>
                    <h3 className="introducingTitle2">
                      <strong>FLIGHT PASS</strong>
                    </h3>
                    <p className="descMain"></p>
                    <p className="descSub">Purchase Now and Get:</p>
                    <div className="benefitList">
                      <div className="leftSec">
                        <ul>
                          <li>Convenience fee: &#x20B9; 0</li>
                          <li>50% off on SpiceMax</li>
                          <li>50% off on Meals & Seats</li>
                          <li>Extra saving in your travel budgets</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="formCol">
                  <h3 class="formTitle mb-5">Flight Pass Registration</h3>
                  <Form>
                    <div className="usernameSection row">
                      <div className="userTitle col-md-4">
                        <label>Title</label>
                        <Field
                          as="select"
                          className="form-control titleInputField"
                          name="title"
                          id="title"
                        >
                          <option value="Mr">Mr</option>
                          <option value="Ms">Ms</option>
                          <option value="Mrs">Mrs</option>
                        </Field>
                      </div>
                      <div className="userName col-md-4">
                        <label>Name ( as per Govt. ID )</label>
                        <Field
                          type="text"
                          className="form-control usernameField regisInput isEmpty transitForm"
                          placeholder="Your First Name"
                          name="firstName"
                          id="firstName "
                          onChange={(e) => {
                            e.preventDefault();
                            const { value } = e.target;
                            let strValue = value.toString();
                            strValue = strValue.replace(/[^A-Za-z]/gi, "");
                            formik.setFieldValue("firstName", strValue);
                          }}
                        />
                        <ErrorMessage name="firstName">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="lastnameSection lastnamealign  col-md-4">
                        <label></label>
                        <Field
                          id="lastName"
                          type="text"
                          className="form-control lastnameField regisInput isEmpty transitForm"
                          placeholder="Your Last Name"
                          name="lastName"
                          onChange={(e) => {
                            e.preventDefault();
                            const { value } = e.target;
                            let strValue2 = value.toString();
                            strValue2 = strValue2.replace(/[^A-Za-z]/gi, "");
                            formik.setFieldValue("lastName", strValue2);
                          }}
                        />
                        <ErrorMessage name="lastName">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>
                    <div className="usernameSection row mt-4">
                      <div className="userTitle  col-md-4">
                        <label>Your ID proof</label>
                        <Field
                          as="select"
                          className="form-control titleInputField"
                          name="id"
                          id="id"
                        >
                          <option value="PAN">PAN</option>
                          <option value="Passport">Passport</option>
                        </Field>
                      </div>
                      <div className="userName  col-md-4">
                        <label>Govt. ID card no.</label>
                        <Field
                          id="idnum"
                          type="text"
                          className="form-control usernameField regisInput isEmpty transitForm"
                          placeholder="Passport/Pan No."
                          name="idnum"
                        />
                        <ErrorMessage name="idnum">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="lastnameSection  col-md-4">
                        <label2>Date of Birth ( as per Govt. ID )</label2>

                        <input
                          type="date"
                          className="form-control dobField regisInput isEmpty"
                          name="date"
                          maxLength="8"
                          value={formik.values.date}
                          min={this.state.mindate}
                          max={this.state.maxdate}
                          onKeyDown={(e) => e.preventDefault()}
                          onChange={formik.handleChange}
                        />
                        <ErrorMessage name="date">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>
                    <div className="phoneSec row">
                      <div className="col-md-12">
                        <label>
                          Your Contact Details ( Mobile Number would become your
                          Member ID )
                        </label>
                      </div>
                      <div className="col-md-4 scloginform">
                        <label> Mobile Number* </label>
                        <PhoneInput
                          id="mobile"
                          name="mobile"
                          country={"in"}
                          onlyCountries={["in"]}
                          value={formik.values.mobile}
                          onBlur={formik.setFieldTouched}
                          onChange={(value) => {
                            formik.setFieldValue("mobile", value, true);
                          }}
                        />
                        <ErrorMessage name="mobile">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <div className="col-md-4">
                        <label>Email ID* </label>
                        <Field
                          id="email"
                          type="email"
                          className="form-control regisInput emailField isEmpty transitForm"
                          placeholder="Email Address"
                          name="email"
                        />
                        <p className="registrationEmailError">
                          *Please enter a valid email address
                        </p>
                        <ErrorMessage name="email">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>

                    <div className="passwordSection row">
                      <div className="col-md-12">
                        <label className="popover__wrapper">
                          Set Password <span className="passwordInfo"></span>
                          <div className="popover__content">
                            <p>
                              Password must be AlphaNumeric and must contain
                              atleast one special character(@#$%&) and minimum 8
                              characters length
                            </p>
                            {/* <p>Password must be alpha numeric </p>
                            <p>
                              Be a minimum of 8 characters in length and maximum
                              of 16 characters
                            </p>
                            <p>
                              Must contain at least one special character from
                              the following categories &@#$%{" "}
                            </p> */}
                          </div>
                        </label>
                      </div>
                      <div className="col-md-4">
                        <Field
                          type="password"
                          className="passwordField regisInput form-control"
                          placeholder="Enter Password"
                          name="pass1"
                          id="pass1"
                        />
                        <ErrorMessage name="pass1">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <div className="col-md-4">
                        <Field
                          id="pass2"
                          type="password"
                          className="confirmPasswordField regisInput form-control"
                          placeholder="Retype Password"
                          name="pass2"
                        />
                        <ErrorMessage name="pass2">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="col-md-12 mt-4">
                        <Field type="checkbox" id="terms" name="terms" />
                        {/* <span className="checkmark"></span> */}
                        <label id="checkboxLabel" className="registrationPage ">
                          I agree to register as a member by accepting the{" "}
                          <span
                            class="text-danger"
                            onClick={() => this.tncModal()}
                          >
                            Terms and Conditions
                          </span>{" "}
                          of SpiceClub
                          <br />
                        </label>
                        <ErrorMessage name="terms">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <button type="submit" className="signUp ml-3">
                        Registration
                      </button>
                    </div>
                  </Form>
                </div>
                <Modal size="sm" className="modal fade" show={this.state.show}>
                  <Modal.Header className="modal-header modalheader d-block">
                    <h2
                      className="modal-title  text-center"
                      id="exampleModalLongTitle"
                    >
                      OTP{" "}
                    </h2>
                  </Modal.Header>
                  <Modal.Body className="modal-body pl-5 pr-5 text-center">
                    <label>
                      <strong>Enter One Time Password</strong>
                    </label>
                    <div
                      className="inputBox1"
                      style={{ marginBottom: "10px !important" }}
                    >
                      <input
                        type="text"
                        name="Traveller"
                        className="input"
                        pattern="[0-9]*"
                        maxLength="6"
                        placeholder="Enter OTP"
                        onChange={this.onOtpChange}
                      />
                    </div>
                    <div className="mb-1">
                      {this.state.isOtpValid ? (
                        <small style={{ color: "red", marginTop: "-20px" }}>
                          {this.state.otpError}
                        </small>
                      ) : null}
                    </div>
                    <button
                      className="btn btn-danger"
                      onClick={this.checkValidtyHandler}
                      disabled={this.state.buttonDisable}
                    >
                      Confirm
                    </button>
                    <p className="pt-3">{/* <timer></timer> */}</p>
                    <Timer
                      parentCallback={this.callbackFunction}
                      mobile={this.state.setValues.mobile}
                    />
                  </Modal.Body>
                </Modal>

                {/* T&C Modal popup */}

                <Modal
                  size="md"
                  className="modal fade"
                  onHide={this.closetnc}
                  show={this.state.tncshow}
                >
                  <Modal.Header
                    closeButton
                    className="modal-header modalheader"
                  >
                    <h2
                      className="modal-title  text-center"
                      id="exampleModalLongTitle"
                    >
                      Term &amp; Conditions{" "}
                    </h2>
                  </Modal.Header>
                  <Modal.Body className="modal-body pl-5 pr-5 text-center">
                    <p> lorem </p>
                  </Modal.Body>
                </Modal>
              </div>
            </div>
          </div>
        )}
      </Formik>
    );
  }
}

export default withRouter(Registration);
