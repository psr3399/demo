import React, { Component } from "react";
import PropTypes from "prop-types";
import axios from "axios";
import * as allUrls from '../../Constants/Constants'

class Timer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      minutes: 3,
      seconds: 0,
      ErrorMessage: "",
    };
    // this.ResetClick = this.ResetClick.bind(this);
  }
  //   ResetClick() {
  //     this.setState(state => ({
  //       state.minutes:3,

  //     }));
  //   }
  static propTypes = {};
  componentDidMount() {
    this.timerFunc();
  }

  timerFunc = () => {
    // this.props.parentCallback(this.state.minutes,this.state.seconds)
    this.myInterval = setInterval(() => {
      const { seconds, minutes } = this.state;
      console.log(
        "from timer interval",
        this.state.minutes,
        this.state.seconds
      );

      this.props.parentCallback(this.state.minutes, this.state.seconds);

      if (seconds > 0) {
        this.setState(({ seconds }) => ({
          seconds: seconds - 1,
        }));
      }
      if (seconds === 0) {
        if (minutes === 0) {
          // this.setState({
          //   ErrorMessage: "Your OTP expired. Please resend OTP request",
          //   minutes: 0,
          //   seconds: 0,
          // });
          clearInterval(this.myInterval);
        } else {
          this.setState(({ minutes }) => ({
            minutes: minutes - 1,
            seconds: 59,
          }));
        }
      }
      if (minutes === 0 && seconds === 0) {
        this.props.parentCallback(this.state.minutes, this.state.seconds);
        this.setState({ ErrorMessage: "Your OTP has expired!" });
      }
    }, 1000);
  };
  resendOtpHandler = () => {
    const ReSendOTPSC = allUrls.resendOtpscUrl;
    const ReSendOTPSCData = {
      mobilenumber: this.props.mobile,
      emailaddress: "",
      CardHolderName: "",
    };
    axios.post(ReSendOTPSC, ReSendOTPSCData).then((res) => {
      this.setState({
        ErrorMessage: "New OTP sent to your mobile number",
        minutes: 3,
        seconds: 0,
      });
      // this.props.parentCallback(this.state.minutes,this.state.seconds)
      this.timerFunc();
    });
  };
  render() {
    const { minutes, seconds } = this.state;
    return (
      <div>
        <p>
          OTP will expire in next {this.state.minutes} minute{" "}
          {this.state.seconds} seconds
        </p>
        <div className="mb-1">
          <small style={{ color: "red" }}>{this.state.ErrorMessage}</small>
        </div>
        <button className="btn btn-danger" onClick={this.resendOtpHandler}>
          Re-Send OTP
        </button>
      </div>
    );
  }
}

export default Timer;
