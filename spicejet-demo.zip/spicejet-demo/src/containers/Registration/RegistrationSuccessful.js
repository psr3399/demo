import React, { Component } from "react";
import { withRouter } from "react-router";
import tickmarkimg from "../../assets/images/checked-user-xxl.png";

class RegistrationSuccessful extends Component {
  startLogin = () => {
    this.props.history.push({
      pathname: "/",
    });
  };
  render() {
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-12 text-center mt-5">
            <img
              src={tickmarkimg}
              className="img-fluid"
              style={{ width: "20%" }}
              alt=""
            />
          </div>

          <div className="col-md-12 text-center">
            <div className="thank-you-pop">
              <h1 className="text-danger mb-4 mt-2">Congratulations!</h1>
              <p>You have successfully registered for Flight Pass</p>
              <h3 className="cupon-pop">
                Please login to continue and enjoy the benefits.
              </h3>
            </div>
            <button
              type="button"
              class="loginButton btn btn-danger mb-5 btn-lg"
              onClick={this.startLogin}
            >
              LOGIN
            </button>
          </div>
        </div>
      </div>
    );
  }
}

export default withRouter(RegistrationSuccessful);
