import React, { Component } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import Auxiliary from "../../../hoc/Auxiliary/Auxiliary";
import Button from "react-bootstrap/Button";
import axios from "axios";
import { connect } from "react-redux";
// import {Route,Link} from 'react-router-dom'
// import FlightPass from '../../FlightPass/FlightPass'
import { withRouter } from "react-router";
import * as loginActions from "../../../store/actions/index";
import Spinner from "../../../component/Spinner/Spinner";
import PropTypes from "prop-types";

class AgencyId extends Component {
  state = {
    // userData:{},
    DomainCode: "www",
    AgentId: "",
    Password: "",
    isLoggedIn: false,
    agentError: "",
    passwordError: "",
    isLoggedInAgent: false,
    // isFormValid:false
  };
  static propTypes = {};

  onSubmit = () => {
    console.log("onStartInit started");
    const isFormValid = this.inputValidation();
    console.log("isFormValid:" + isFormValid);
    if (isFormValid) {
      console.log("isFormValid2:" + isFormValid);
      this.props.onStartInit(
        this.state.DomainCode,
        this.state.AgentId,
        this.state.Password,
        this.state.isLoggedInAgent
      );
      this.setState({ agentError: "", passwordError: "" });
    }
  };

  inputValidation = () => {
    console.log(
      "AgentId:" + this.state.AgentId,
      "Password:" + this.state.Password
    );

    if (this.state.AgentId.length == 0) {
      this.setState({ agentError: "*Agent Id. Required" });
      this.setState({ passwordError: "" });
      return false;
    } else this.setState({ agentError: "" });

    if (this.state.Password.length == 0) {
      this.setState({ passwordError: "*Password Required" });
      return false;
    } else this.setState({ passwordError: "" });
    return true;
  };
  componentDidUpdate = () => {
    this.dataCame();
  };

  dataCame = () => {
    if (this.props.isLoggedInAgent) {
      this.props.history.push({
        pathname: "/agentDashboard",
      });
    }
  };
  render() {
    let realform = (
      <form>
        <label forof="agentid">Agency ID</label>
        <br />
        <input
          type="text"
          id="agentid"
          value={this.state.AgentId}
          onChange={(e) => this.setState({ AgentId: e.target.value })}
          name="agentid"
          className="form-control"
        />
        <small style={{ color: "red" }}>{this.state.agentError}</small>
        <br />
        <label forof="lname">Password</label>
        <br />
        <input
          type="password"
          id="lname"
          onChange={(e) => this.setState({ Password: e.target.value })}
          name="lname"
          className="form-control"
        />
        <small style={{ color: "red" }}>{this.state.passwordError}</small>

        <br />
        <br />
        <a
          href="https://book.spicejet.com/FindPassword.aspx"
          target="_blank"
          className="forgotPasswordLink"
        >
          Forgot Password?
        </a>

        <Button
          variant="danger"
          onClick={this.onSubmit}
          className="loginButton"
        >
          Log in
        </Button>
      </form>
    );
    if (this.props.loading) {
      realform = <Spinner />;
    }

    return (
      <Auxiliary>
        <br />
        {realform}
        {/* {this.state.userData == null ? console.log('id/pass wrong') : ((Object.keys(this.state.userData).length) ? this.dataCame() : null) } */}
      </Auxiliary>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    loading: state.login.loading,
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onStartInit: (DomainCode, AgentId, Password, isLoggedInAgent) =>
      dispatch(
        loginActions.onPostAgentLogin(
          DomainCode,
          AgentId,
          Password,
          isLoggedInAgent
        )
      ),
    loginInit: (isLoggedInAgent) =>
      dispatch(loginActions.auth(isLoggedInAgent)),
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgencyId));
