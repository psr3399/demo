import React, { Component } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import Auxiliary from "../../../hoc/Auxiliary/Auxiliary";
import Button from "react-bootstrap/Button";
import axios from "axios";
import { connect } from "react-redux";
// import {Route,Link} from 'react-router-dom'
// import FlightPass from '../../FlightPass/FlightPass'
import { withRouter } from "react-router";
import * as loginActions from "../../../store/actions/index";
import Spinner from "../../../component/Spinner/Spinner";
import { ValidationError } from "yup";

class ScMember extends Component {
  state = {
    // userData:{},
    DomainCode: "mweb",
    MobileOrEmail: "",
    Password: "",
    isLoggedIn: false,
    emailError: "",
    mobileError: "",
    passwordError: "",
    // isFormValid:false
  };
  

  onSubmit = () => {
    console.log("onStartInit started");
    const isFormValid = this.inputValidation();

    if (isFormValid) {
      this.props.onStartInit(
        this.state.DomainCode,
        this.state.MobileOrEmail,
        this.state.Password,
        this.state.isLoggedIn
      );
      this.setState({ mobileError: "", passwordError: "" });
    }
  };

  inputValidation = () => {
    // console.log(this.state.MobileOrEmail,this.state.Password)

    if (this.state.MobileOrEmail.length == 0) {
      this.setState({ mobileError: "*Phone No. Required" });
      this.setState({ passwordError: "" });
      return false;
    } else this.setState({ mobileError: "" });

    if (this.state.Password.length == 0) {
      this.setState({ passwordError: "*Password Required" });
      return false;
    } else this.setState({ passwordError: "" });
    return true;
  };

  componentDidUpdate = () => {
    this.dataCame();
  };

  dataCame = () => {
    console.log(this.props , 'enter');
   
    if (this.props.isLoggedIn) {
     
      this.props.history.push({
        pathname: "/flightpass",
      });
    }
  };

  render() {
    let realform = (
      <form className="scloginform">
        SpiceClubMember ID or Email ID:
        <PhoneInput
          country={"in"}
          value={this.state.MobileOrEmail}
          onChange={(phone) => this.setState({ MobileOrEmail: phone })}
        />
        <small style={{ color: "red" }}>{this.state.mobileError}</small>
        <br />
        <label forof="lname">Password</label>
        <br />
        <input
          type="password"
          id="lname"
          onChange={(e) => this.setState({ Password: e.target.value })}
          name="lname"
          className="form-control"
        />
        <small style={{ color: "red" }}>{this.state.passwordError}</small>
        <br />
        <br />
        <a
          href="https://book.spicejet.com/FindPassword.aspx"
          target="_blank"
          className="forgotPasswordLink"
        >
          Forgot Password?
        </a>
        <Button
          variant="danger"
          onClick={this.onSubmit}
          className="loginButton"
        >
          Log in
        </Button>
      </form>
    );
    if (this.props.loading) {
      realform = <Spinner />;
    }

    return (
      <Auxiliary>
        <br />
        {realform}
        {/* {this.state.userData == null ? console.log('id/pass wrong') : ((Object.keys(this.state.userData).length) ? this.dataCame() : null) } */}
      </Auxiliary>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.login.loading,
    details: state.login.userData,
    isLoggedIn: state.login.isLoggedIn,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onStartInit: (DomainCode, MobileOrEmail, Password, isLoggedIn) =>
      dispatch(
        loginActions.onPostLogin(
          DomainCode,
          MobileOrEmail,
          Password,
          isLoggedIn
        )
      ),
    loginInit: (isLoggedIn) => dispatch(loginActions.auth(isLoggedIn)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ScMember));
