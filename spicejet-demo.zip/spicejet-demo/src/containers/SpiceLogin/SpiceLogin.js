import React, { Component } from "react";
import Auxiliary from "../../hoc/Auxiliary/Auxiliary";
import Tabs from "react-bootstrap/Tabs";
import Tab from "react-bootstrap/Tab";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import ScMember from "./ScMember/ScMember";
import AgencyId from "./AgencyId/AgencyId";
import Intro from "../../assets/images/postlogin/intro.png";
import background from "../../assets/images/postlogin/fplogo4.png";
export default class SpiceLogin extends Component {
  render() {
    return (
      <Auxiliary>
        <div className="loginPage mainBanner">
          <div className="mainbannerhome">
            <div className="container-fluid">
              <div className="row">
                <div className="col-md-6">
                  <div className="mainlogo ml-5 mt-4">
                    <div className="">
                      <img src={background} className="img-fluid" />
                    </div>
                    <h6 className="headerDesc">
                      Book and fly with unequalled flexibility!
                    </h6>
                  </div>
                </div>
                <div className="col-md-6 pt-4">
                  <div className="loginPage mainBanner">
                    <div className="loginFormWrapper">
                      <h6 className="headerDesc" style={{ fontsize: "13px" }}>
                        Login with SpiceClubMembership/Agency ID
                      </h6>
                      <div className="loginForm">
                        <Container>
                          <Row>
                            <Col>
                              <Tabs
                                defaultActiveKey="home"
                                transition={false}
                                id="noanim-tab-example"
                              >
                                <Tab eventKey="home" title="SC Member">
                                  <ScMember />
                                  <p className="notRegistered">
                                    Not registered yet?
                                  </p>
                                  <a href="/registration" className="signupnow">
                                    SIGN-UP NOW
                                  </a>
                                </Tab>
                                <Tab eventKey="profile" title="Agency ID">
                                  <AgencyId />
                                </Tab>
                              </Tabs>
                            </Col>
                          </Row>
                        </Container>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="spiceClubAboutWrapper">
            <div className="spiceClubContainer">
              <h3>
                <span></span>About SpiceJet Flight Pass
              </h3>
              <div className="spiceClubConetnt">
                <div className="imageSection">
                  <img src={Intro} alt="flight pass" />
                </div>

                <div className="descSection">
                  <p>
                    Are you travelling frequently and last minute price hikes
                    are burning holes in your pocket?
                    <br />
                    We have a product just for you!{" "}
                    <strong>Now lock your fares and fly anytime*</strong>.<br />
                    <br />
                    Conveniently pre-purchase flights at a LOW PRICE using
                    flight pass and book flights later when you want to travel.
                    No matter where or how often you fly, the Flight Pass allows
                    you to minimize your total flying costs by locking-in your
                    low fare and avoiding future fare increases.
                    <br />
                    <br />
                    Fly to more than 40 destinations with the Flight Pass of
                    your choice. There are no black-out dates or hidden
                    restrictions or additional fees. Book any flight that is
                    available for purchase till the last unsold seat,
                    irrespective of available fare, subject to the flight pass
                    terms and balance flight count remaining in the pass.
                    <br />
                    <br />
                  </p>
                </div>

                <a href="/" className="carouselSignupLink">
                  Buy Now!
                </a>
              </div>
            </div>
          </div>

          <div className="ContentWrapper earnPointsPage">
            <div className="subContentwrapper">
              <div id="flightadd" className="tab-pane active">
                <h3 className="tabpanehead">
                  {" "}
                  Benefits of SpiceJet Flight Pass{" "}
                </h3>
                <p className="earnupto">
                  With Spicejet Flight Pass and enhance your travel convenience.
                  You can fly more, pay up to 50% less, save time &amp; effort
                  in trip planning.
                </p>
                <div className="earnPointsPageSrollPointList">
                  <div className="row pointsList">
                    <div className="pointsListItems spiceMax">
                      <h2>Destination of your choice</h2>
                      <p>
                        Fly to any domestic destination in India with the same
                        pass.
                      </p>
                    </div>
                    <div className="pointsListItems preferredSeats">
                      <h2>Customizeable</h2>
                      <p>
                        Choose the Number of Flights in your Flight Pass and its
                        Validity
                      </p>
                    </div>
                    <div className="pointsListItems hotMeals">
                      <h2>Discounted Add-ons</h2>
                      <p>
                        Get exciting discounts on Add-ons- SpiceMax, Meals,
                        Seats, You-1st
                      </p>
                    </div>
                    <div className="pointsListItems baggage">
                      <h2>First in queue</h2>
                      <p>
                        Dedicated helpdesk for booking, Priorty Check-in,
                        Boarding and more
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="subContentwrapper">
              <h2 className="spiceClubtierHead">Pricing</h2>
              <div className="compareInfo">
                <p>
                  Plan your travel budget and choose the flight pass suiting
                  your needs the best. <br />
                  <strong>Price per flight</strong> for each type of Flight Pass
                  is mentioned below:
                </p>
              </div>
              <div className="tableMainWrapperTiersPage">
                <div className="tableFixedSectionWrapper">
                  <h3 className="fixedSectionheader">Travel Validity --&gt;</h3>
                  <ul className="paddingZero">
                    <li className="fixedtableSections loyaltyPoints">
                      No. of Flights in the Pass
                    </li>
                    <li className="compareList">10 flights</li>
                    <li className="compareList">25 flights</li>
                    <li className="compareList">50 flights</li>
                    <li className="compareList">100 flights</li>
                  </ul>
                </div>

                <div className="tableresponsivescroll">
                  <div className="tableScrollableSectionWrapper">
                    <div className="subSection">
                      <ul className="paddingZero">
                        <li className="silver category">6 Months</li>
                        <li className="fixedtableSections loyaltyPoints adjustli"></li>
                        <li className="compareList ">₹ 5,100</li>
                        <li className="compareList">₹ 4,800</li>
                        <li className="compareList">₹ 4,500</li>
                        <li className="compareList">₹ 4,200</li>
                      </ul>
                    </div>

                    <div className="subSection">
                      <ul className="paddingZero">
                        <li className="platinum category">12 months</li>
                        <li className="fixedtableSections loyaltyPoints adjustli"></li>
                        <li className="compareList ">₹ 6,000</li>
                        <li className="compareList">₹ 5,700</li>
                        <li className="compareList">₹ 5,400</li>
                        <li className="compareList">₹ 5,100</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="ContentWrapper spicecashPage">
              <div className="moreSection" id="moreInfo">
                <div className="subContentwrapper">
                  <h2>How to use</h2>
                  <div className="spicecashTabs">
                    <div className="scrollable"></div>
                    <div className="tab-content" id="pills-tabContent">
                      <div
                        className="tab-pane fade show active"
                        id="use-spicecash"
                        role="tabpanel"
                        aria-labelledby="use-spicecash-tab"
                      >
                        <div className="row useSpicecashSec">
                          <div className="col-md-6 bookFlights">
                            <h3>BUY FLIGHT PASS</h3>
                            <div className="useSpiceLeft">
                              <p className="loginForBal">
                                If you are a new Flight pass customer, log-in
                                using your SpiceClub username and password or
                                Sign-up!.
                              </p>
                              <p className="chooseFlight">
                                Choose the no. of flights you want in the pass
                                and the validity of the pass
                              </p>
                              <p className="payAmount">
                                Pay the Flight pass amount through Credit card,
                                Debit card, Netbanking, UPI, e-wallets.
                              </p>
                              <p className="enterOtp">
                                When prompted, Enter OTP sent to your registered
                                mobile number, to complete the transaction.
                              </p>
                              <p className="enjoyFlight">
                                Complete your booking and Flight pass will be
                                delivered to your registered email-address
                              </p>
                              <p className="sameInfo">
                                You need to provide a valid Identification card
                                number (Passport/ PAN card) for purchasing the
                                flight pass. ID provided would be verified at
                                the airport before commencement of Travel.
                              </p>
                            </div>
                          </div>
                          <div className="col-md-6 onlineMerchant">
                            <h3>USE FLIGHT PASS</h3>
                            <div className="useSpiceRight">
                              <p className="loginSpicecash">
                                Call our Reservations Helpdesk through the
                                registered mobile number and provide your
                                Username and Flight Pass ID.
                              </p>
                              <p className="chooseFlight">
                                Choose your flight, provide Traveller details
                                and purchase add-ons{" "}
                              </p>
                              <p className="locateCard">
                                Our executive would validate your Flight pass
                                and Traveller details
                              </p>
                              <p className="enoughBal">
                                Pay for Add-on amount using other payment modes
                                using IVR or payment link sent to you.
                              </p>
                              <p className="enterExpiry">
                                Once succesful, your itinerary would be sent
                                through an email to your registered email
                                address.{" "}
                              </p>
                              <p className="sameInfo">
                                For succesful booking, Traveller details should
                                match with the flight pass member details;
                                Flight pass should be valid and should not be
                                fully utilized.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="termsConditions">
                <div className="subContentwrapper">
                  <h2>FAQs and T&amp;Cs</h2>
                  <div id="accordion" className="accordion">
                    <div className="card mb-3">
                      <div className="card-header" id="headingOne">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link p-0"
                            data-toggle="collapse"
                            data-target="#collapseOne"
                            aria-expanded="true"
                            aria-controls="collapseOne"
                          >
                            Q1
                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapseOne"
                        className="collapse show"
                        aria-labelledby="headingOne"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <div className="card mb-3">
                      <div className="card-header" id="headingTwo">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link collapsed p-0"
                            data-toggle="collapse"
                            data-target="#collapseTwo"
                            aria-expanded="false"
                            aria-controls="collapseTwo"
                          >
                            ..
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseTwo"
                        className="collapse"
                        aria-labelledby="headingTwo"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <div className="card mb-3">
                      <div className="card-header" id="headingThree">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link collapsed p-0"
                            data-toggle="collapse"
                            data-target="#collapseThree"
                            aria-expanded="false"
                            aria-controls="collapseThree"
                          >
                            ..
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseThree"
                        className="collapse"
                        aria-labelledby="headingThree"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <div className="card mb-3">
                      <div className="card-header" id="headingFour">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link collapsed p-0"
                            data-toggle="collapse"
                            data-target="#collapseFour"
                            aria-expanded="false"
                            aria-controls="collapseFour"
                          >
                            ..
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseFour"
                        className="collapse"
                        aria-labelledby="headingFour"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <div className="card mb-3">
                      <div className="card-header" id="headingFive">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link collapsed p-0"
                            data-toggle="collapse"
                            data-target="#collapseFive"
                            aria-expanded="false"
                            aria-controls="collapseFive"
                          >
                            ..
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseFive"
                        className="collapse"
                        aria-labelledby="headingFive"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p></p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                    <div className="card mb-0">
                      <div className="card-header" id="headingSix">
                        <h5 className="mb-0">
                          <button
                            className="btn btn-link collapsed p-0"
                            data-toggle="collapse"
                            data-target="#collapseSix"
                            aria-expanded="false"
                            aria-controls="collapseSix"
                          >
                            SpiceJet Flight Pass Terms &amp; Conditions
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseSix"
                        className="collapse"
                        aria-labelledby="headingSix"
                        data-parent="#accordion"
                      >
                        <div className="card-body">
                          <p>..</p>
                          <p></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Auxiliary>
    );
  }
}
