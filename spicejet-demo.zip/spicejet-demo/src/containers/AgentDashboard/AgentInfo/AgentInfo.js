import React, { Component } from "react";
import "./AgentInfo.css";
import Auxiliary from "../../../hoc/Auxiliary/Auxiliary";
import { connect } from "react-redux";
import { withRouter } from "react-router";
class AgentInfo extends Component {
  // constructor(props){
  // super(props);
  // this.state = {};
  // }

  // componentWillMount(){}
  // componentDidMount(){}
  // componentWillUnmount(){}

  // componentWillReceiveProps(){}
  // shouldComponentUpdate(){}
  // componentWillUpdate(){}
  // componentDidUpdate(){}
  state = {
    userData: {},
    isLoggedInAgent: false,
  };
  componentDidMount = () => {
    if (!this.props.isLoggedInAgent) {
      this.props.history.push("/");
    }
    this.setState({ userData: this.props.userData });
    this.setState({ isLoggedInAgent: this.props.isLoggedInAgent });
  };
  componentDidUpdate = () => {
    if (this.props.match.path !== "/") {
      if (!this.props.isLoggedInAgent) {
        this.props.history.push("/");
      }
    }
  };
  render() {
    return (
      <Auxiliary>
        <span className="accountimg">
          <i className="fa fa-user-circle-o"></i>
        </span>
        <h4 style={{ textTransform: "uppercase" }}>
          {this.props.details.Title}.{this.props.details.FullName}
        </h4>
        <p>Agency ID: {this.props.details.UserName}</p>
        <p>Email Address: {this.props.details.EmailID}</p>
      </Auxiliary>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
    tableData: state.login.tableData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentInfo));
