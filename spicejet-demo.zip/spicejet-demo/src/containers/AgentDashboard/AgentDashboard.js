import React, { Component } from "react";
import Auxiliary from "../../hoc/Auxiliary/Auxiliary";
import Searchcustomer from "./Searchcustomer/Searchcustomer";
import AgentInfo from "./AgentInfo/AgentInfo";
import AddTraveller from "./AddTraveller";
import Travellerslist from "./Travellerslist";
import { button, Modal } from "react-bootstrap";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import Spinner from "../../component/Spinner/Spinner"



class AgentDashboard extends Component {
  state = {
    // show:this.props.loadingAgentTable
  }
  render() {
    console.log('props.loadislk', this.props.loadingAgentTable)
    let tableloading = null
    if (this.props.loadingAgentTable) {
      tableloading = <Spinner />
    }else{
      tableloading = 'TABLE LOADED'
    }
    
    return (
      <Auxiliary>
        <div className="container-fluid dullredbg">
          <div className="container">
            <div className="row align-items-center h-100">
              <div className="col-md-5 pt-5">
                <AgentInfo />
              </div>
              <div className="col-md-7"><Searchcustomer /></div>
            </div>
          </div>
        </div>
        <Modal size="sm" className="modal fade" show={this.props.loadingAgentTable}>
          {/* <Modal.Header className="modal-header modalheader d-block">
            <h2
              className="modal-title  text-center"
              id="exampleModalLongTitle"
            >
              OTP{" "}
            </h2>
          </Modal.Header> */}
          <Modal.Body className="modal-body pl-5 pr-5 text-center">
            {tableloading}
          </Modal.Body>
        </Modal>
        {/* <div className="container-fluid">
          <AddTraveller />
        </div> */}
        <div className="container-fluid mt-5">
        <Travellerslist />
        </div>
      </Auxiliary>
    );
  }
}


const mapStateToProps = (state) => {
  return {
    loadingAgentTable:state.login.loadingAgentTable
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
 };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentDashboard));
