import React, { Component } from "react";
import "./Travellerslist.css";
import axios from "axios";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import * as loginActions from "../../../store/actions/index";
import ReactTable from "react-table-6";
import "react-table-6/react-table.css";

class Travellerslist extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columns: [
        {
          Header: "Customer Name",
          accessor: "CustomerName",
        },
        {
          Header: "Mobile Number",
          accessor: "MobileNumber",
        },
        {
          Header: "DOB",
          accessor: "DOB",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Govt ID",
          accessor: "GovtID",
          sortable: false,
          filtarable: false,
        },

        {
          Header: "Action",
          Cell: (props) => {
            return (
              <button
                className="btn btn-danger btn-sm"
                onClick={() => {
                  console.log("props", props);
                  this.buydetails(props.original);
                }}
              >
                BUY FLIGHT PASS
              </button>
            );
          },
        },
      ],
      columsLvelZero: [
        {
          Header: "Flight Pass ID",
          accessor: "FlightPassID",
        },
        {
          Header: "Pass Type",
          accessor: "PassType",
        },
        {
          Header: "Total Flight Count",
          accessor: "TotalVoucherCount",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Status",
          accessor: "Status",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Valid Till",
          accessor: "ValidTill",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Validity",
          accessor: "validity",
          sortable: false,
          filtarable: false,
        },
      ],
      columnsLevelOne: [
        {
          Header: "Flight Count ID",
          accessor: "VoucherCode",
        },
        {
          Header: "Flight Count Amount",
          accessor: "VoucherAmount",
        },
        {
          Header: "PNR",
          accessor: "PNR",
        },
        {
          Header: "BookingDate",
          accessor: "BookingDate",
        },
        {
          Header: "ExpireDate",
          accessor: "ExpireDate",
        },
        {
          Header: "Status",
          accessor: "Status",
        },
      ],
      rowData: [],
    };
  }

  componentDidMount() {
    this.props.onInitAgentTable(this.props.details.UserName);
    // var url =
    //   "http://122.15.2.126/Pass/api/FlightPass/getAgentData?id=" +
    //   this.props.details.UserName;
    // axios.get(url).then((res) => {
    //   this.setState({ rowData: res.data });
    // });
  }
  buydetails = (originalData) => {
    this.props.onSelectRowHandler(originalData);
    this.props.history.push({
      pathname: "/AgentPay",
    });
  };
  filterCaseInsensitive(filter, row) {
    const id = filter.pivotId || filter.id;
    return row[id] != undefined
      ? String(row[id].toLowerCase()).startsWith(filter.value.toLowerCase())
      : true;
  }
  render() {
    // debugger;
    console.log(
      "these are the passenger details",
      this.props.selectedPassenger
    );

    return (
      <div className="container mb-5">
        <h4 className="redtxt mb-4">Traveller(s) List</h4>
        <div
          className="ag-theme-alpine"
          style={{ height: "auto", margin: "30px 0px" }}
        >
          <div className="card">
            <ReactTable
              data={this.props.userTableData ? this.props.userTableData : null}
              columns={this.state.columns}
              filterable={true}
              sortable={true}
              defaultPageSize={5}
              defaultFilterMethod={this.filterCaseInsensitive}
              SubComponent={(row) => {
                console.log("row" + JSON.stringify(row));
                return (
                  <ReactTable
                    data={row.original.FlightPasses}
                    columns={this.state.columsLvelZero}
                    defaultPageSize={5}
                    defaultFilterMethod={this.filterCaseInsensitive}
                    SubComponent={(row) => {
                      console.log("row" + JSON.stringify(row));
                      return (
                        <ReactTable
                          data={row.original.Vouchers}
                          columns={this.state.columnsLevelOne}
                          defaultPageSize={5}
                          defaultFilterMethod={this.filterCaseInsensitive}
                        />
                      );
                    }}
                  />
                );
              }}
            />
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
    tableData: state.login.tableData,
    personData: state.login.personData,
    selectedPassenger: state.login.selectedPassenger,
    userTableData: state.login.userTableData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onSelectRowHandler: (rdata) =>
      dispatch(loginActions.setPassengerDetails(rdata)),
    onInitTravellerTable: (userNameData) =>
      dispatch(loginActions.initTravellerTable(userNameData)),
    onInitAgentTable: (userNameData) =>
      dispatch(loginActions.initAgentTable(userNameData)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(Travellerslist));
