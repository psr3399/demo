import React, { Component } from "react";
import "./Searchcustomer.css";
import PhoneInput from "react-phone-input-2";
import axios from "axios";
import { withRouter } from "react-router";
import { button, Modal } from "react-bootstrap";
import { connect } from "react-redux";
import * as loginActions from "../../../store/actions/index";
import moment from "moment";
import * as allUrls from "../../../Constants/Constants";

class Searchcustomer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Title: "Mr",
      FirstName: "",
      LastName: "",
      DOB: "",
      Email: "",
      Mobile: "",
      IdProofType: "",
      IdProof: "",
      TitleError: "",
      terms: false,
      FirstNameError: "",
      LastNameError: "",
      EmailError: "",
      MobileError: "",
      IdProofTypeError: "",
      IdProofError: "",
      DOBError: "",
      termsValidyError: "",
      maxdate: moment().add(-18, "year").format("YYYY-MM-DD"),
      mindate: moment().add(-100, "year").format("YYYY-MM-DD"),
      tncshow: false,
    };
    this.handleTitle = this.handleTitle.bind(this);
    this.handleFirstName = this.handleFirstName.bind(this);
    this.handleLastName = this.handleLastName.bind(this);
    this.handleEmail = this.handleEmail.bind(this);
    // this.handleMobile = this.handleMobile.bind(this);
    this.handleIdProofType = this.handleIdProofType.bind(this);
    this.handleIdProof = this.handleIdProof.bind(this);
    this.handleDOBChange = this.handleDOBChange.bind(this);
    this.handleTermsCheck = this.handleTermsCheck.bind(this);
  }
  tncModal() {
    this.setState({ tncshow: true });
  }
  closetnc = () => {
    this.setState({ tncshow: false });
  };
  makeFormValuesNull = () => {
    this.setState({
      Title: "Mr",
      FirstName: "",
      LastName: "",
      DOB: "",
      Email: "",
      Mobile: "",
      IdProofType: "",
      IdProof: "",
      terms: false,
    });
  };
  makeErrorsNull = () => {
    this.setState({
      TitleError: "",
      FirstNameError: "",
      termsValidyError: "",
      LastNameError: "",
      EmailError: "",
      MobileError: "",
      IdProofTypeError: "",
      IdProofError: "",
      DOBError: "",
    });
  };

  handleTermsCheck(e) {
    let termsval = !this.state.terms;
    this.setState({ terms: termsval });
    if (!this.state.terms) {
      this.setState({ termsValidyError: "" });
    } else {
      this.setState({ termsValidyError: "*Please accept Terms and Condition" });
    }
  }
  handleDOBChange(e) {
    console.log("handleDOB", e.target.value);
    this.setState({ DOB: e.target.value });
  }
  handleEmail(e) {
    console.log("handleEmail", e.target.value);
    this.setState({ Email: e.target.value });
  }
  // handleMobile(e) {
  //   console.log("handleMobile", e.target.value);
  //   this.setState({ Mobile: e.target.value });
  // }
  handleIdProofType(e) {
    console.log("handleIdProofType", e.target.value);
    this.setState({ IdProofType: e.target.value });
  }
  handleIdProof(e) {
    console.log("handleIdProof", e.target.value);
    this.setState({ IdProof: e.target.value });
  }
  handleTitle(e) {
    console.log("handleTitle", e.target.value);
    this.setState({ Title: e.target.value });
  }
  handleFirstName(e) {
    console.log("handleFirstName", e.target.value);
    let value = e.target.value;
    value = value.replace(/[^A-Za-z]/gi, "");
    this.setState({ FirstName: value });
  }
  handleLastName(e) {
    console.log("handleLastName", e.target.value);
    let value = e.target.value;
    value = value.replace(/[^A-Za-z]/gi, "");
    this.setState({ LastName: value });
  }

  // ===============================ON BLUR EVENTS=========

  onBlurFirstName = () => {
    if (this.state.FirstName == "") {
      this.setState({ FirstNameError: "*Required" });
    } else {
      this.setState({ FirstNameError: "" });
    }
  };

  onBlurLastName = () => {
    if (this.state.LastName == "") {
      this.setState({ LastNameError: "*Required" });
    } else {
      this.setState({ LastNameError: "" });
    }
  };

  onBlurEmail = () => {
    if (this.state.Email == "") {
      this.setState({ EmailError: "*Required" });
    } else if (
      !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.state.Email)
    ) {
      this.setState({ EmailError: "*Invalid Email" });
    } else {
      this.setState({ EmailError: "" });
    }
  };

  onBlurPhone = async () => {
    console.log("mobile no. is", this.state.Mobile);
    if (!this.state.Mobile) {
      this.setState({ MobileError: "enter mobile no." });
      return false;
    } else if (this.state.Mobile) {
      let url =
        allUrls.phoneExistUrl +
        this.state.Mobile +
        "&Crby=" +
        this.props.details.UserName;
      try {
        console.log("inside blur ifExist");
        const res = await axios.get(url);
        console.log("after await", res.data);
        if (res.data === true) {
          console.log("inside if got true exist");
          this.setState({ MobileError: "Traveller already exist." });
          return false;
        } else if (this.state.Mobile.length < 12) {
          this.setState({ MobileError: "*Must be 10 digit" });
          return false;
        } else {
          console.log("inside else no. valid returning true");
          this.setState({ MobileError: "" });
          return true;
        }
      } catch (err) {
        console.log("inside catch");
        return false;
        //  console.log(err)
      }
    }
  };

  onBlurDOB = () => {
    if (this.state.DOB == "") {
      this.setState({ DOBError: "*Required" });
    } else {
      let today = new Date();
      var birthDate = new Date(this.state.DOB);
      var age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 12) {
        this.setState({ DOBError: "Age should be 18" });
      } else {
        this.setState({ DOBError: "" });
      }
    }
  };

  onBlurIdProofType = () => {
    if (this.state.IdProofType == "") {
      this.setState({ IdProofTypeError: "*Required" });
    } else {
      this.setState({ IdProofTypeError: "" });
    }
  };

  onBlurIdProof = () => {
    if (this.state.IdProof == "") {
      this.setState({ IdProofError: "*Required" });
    } else if (
      this.state.IdProofType == "PAN" &&
      !/[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/.test(this.state.IdProof)
    ) {
      this.setState({ IdProofError: "Wrong PAN id" });
    } else if (
      this.state.IdProofType == "Passport" &&
      !/[0-9]$/.test(this.state.IdProof)
    ) {
      this.setState({ IdProofError: "Wrong Passport no." });
    } else {
      this.setState({ IdProofError: "" });
    }
  };

  // ========ON SUBMIT VALIDATION==============

  inputValidation = () => {
    if (this.state.Title == "") {
      this.setState({ TitleError: "*Required" });
      return false;
    }
    if (this.state.FirstName == "") {
      this.setState({ FirstNameError: "*Required" });
      return false;
    }

    if (this.state.LastName == "") {
      this.setState({ LastNameError: "*Required" });
      return false;
    }

    if (this.state.Email == "") {
      this.setState({ EmailError: "*Required" });
      return false;
    } else if (
      !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.state.Email)
    ) {
      this.setState({ EmailError: "*Invalid Email" });
      return false;
    }

    if (this.state.DOB == "") {
      this.setState({ DOBError: "*Required" });
      return false;
    } else {
      let today = new Date();
      var birthDate = new Date(this.state.DOB);
      var age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
      if (age < 12) {
        this.setState({ DOBError: "Age should be 18" });
        return false;
      }
    }
    if (this.state.IdProofType == "") {
      this.setState({ IdProofTypeError: "*Required" });
      return false;
    }
    if (this.state.IdProof == "") {
      this.setState({ IdProofError: "*Required" });
      return false;
    } else if (
      this.state.IdProofType == "PAN" &&
      !/[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/.test(this.state.IdProof)
    ) {
      this.setState({ IdProofError: "Wrong PAN id" });
      return false;
    } else if (
      this.state.IdProofType == "Passport" &&
      !/[0-9]$/.test(this.state.IdProof)
    ) {
      this.setState({ IdProofError: "Wrong Passport no." });
      return false;
    }
    if (!this.state.terms) {
      this.setState({ termsValidyError: "*Please accept Terms and Condition" });
      return false;
    } else {
      this.setState({ termsValidyError: "" });
    }
    return true;
  };

  onSubmit = async () => {
    // debugger;
    // add a trigger here
    this.makeErrorsNull();
    console.log("onSubmit button");
    // console.log(this.state);
    const isFormValid = this.inputValidation();
    const checkMobileExists = await this.onBlurPhone();
    console.log("from on blur", checkMobileExists);
    if (isFormValid && checkMobileExists) {
      var travellerData = {
        CustomerName: this.state.FirstName + " " + this.state.LastName,
        FirstName: this.state.FirstName,
        LastName: this.state.LastName,
        MobileNumber: this.state.Mobile,
        EmailAddress: this.state.Email,
        PAN: this.state.IdProof,
        PurchaseDate: new Date(),
        ExpireDate: new Date(),
        Status: "0",
        Title: this.state.Title,
        ProofType: this.state.IdProofType,
        DOB: this.state.DOB,
        CreatedBy: this.props.details.UserName,
      };
      console.log("valid true sending data", travellerData);

      axios.post(allUrls.addTravellerUrl, travellerData).then((res) => {
        console.log("new traveller", res.data);
        this.props.onInitAgentTable(this.props.details.UserName);
        this.setState({ Mobile: "+91" });
      });
      this.makeFormValuesNull();
    }
  };

  render() {
    // console.log('this is username', this.props.details.UserName)
    return (
      <div className="searchbox text-uppercase">
        <p>Add Traveller Details</p>
        <form className="searchalign buyoption">
          <div className="row">
            <div className="col-md-3">
              <label>Title:</label>
              <div className="inputBox">
                <select
                  className="form-control form-control-sm"
                  onChange={this.handleTitle}
                  value={this.state.Title}
                >
                  <option value="">Select</option>
                  <option value="Mr">Mr.</option>
                  <option value="Ms">Ms.</option>
                  <option value="Mrs">Mrs.</option>
                </select>
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.TitleError}
                  </small>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <label>First Name:</label>
              <div className="inputBox">
                <input
                  type="text"
                  name="Traveller"
                  className="input"
                  placeholder="First Name"
                  onChange={this.handleFirstName}
                  onBlur={this.onBlurFirstName}
                  value={this.state.FirstName}
                />
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.FirstNameError}
                  </small>
                </div>
              </div>
            </div>
            <div className="col-md-5">
              <label>Last Name:</label>
              <div className="inputBox">
                <input
                  type="text"
                  name="Traveller"
                  className="input"
                  placeholder="Last Name"
                  onChange={this.handleLastName}
                  value={this.state.LastName}
                  onBlur={this.onBlurLastName}
                />
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.LastNameError}
                  </small>
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <label>Email Address:</label>
              <div className="inputBox">
                <input
                  type="text"
                  name="Traveller"
                  className="input"
                  placeholder="Email Address"
                  onChange={this.handleEmail}
                  value={this.state.Email}
                  onBlur={this.onBlurEmail}
                />
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.EmailError}
                  </small>
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <label>Mobile Number:</label>
              <div className="inputBox">
                <PhoneInput
                  className="agcalndr"
                  id="mobile"
                  name="mobile"
                  country={"in"}
                  value={this.state.Mobile}
                  onChange={(value) => this.setState({ Mobile: value })}
                  onBlur={this.onBlurPhone}
                />
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.MobileError}
                  </small>
                </div>
              </div>
            </div>
            <div className="col-md-6 agcal">
              <label>Date of Birth ( as per Govt. ID )</label>
              <input
                type="date"
                className="agcalndr text-uppercase quesadilla"
                name="DOB"
                maxLength="8"
                value={this.state.DOB}
                min={this.state.mindate}
                max={this.state.maxdate}
                onKeyDown={(e) => e.preventDefault()}
                onChange={this.handleDOBChange}
                onBlur={this.onBlurDOB}
              />
              <div className="buypasserrdob">
                <small style={{ color: "white" }}>{this.state.DOBError}</small>
              </div>
            </div>
            <div className="col-md-6">
              <label>Govt ID Proof Type</label>
              <div className="inputBox">
                <select
                  className="form-control form-control-sm"
                  onChange={this.handleIdProofType}
                  value={this.state.IdProofType}
                  onBlur={this.onBlurIdProofType}
                >
                  <option value="">Select</option>
                  <option value="PAN">PAN</option>
                  <option value="Passport">Passport</option>
                </select>
                <small style={{ color: "white" }}>
                  {this.state.IdProofTypeError}
                </small>
              </div>
            </div>
            <div className="col-md-6">
              <label>Govt ID Proof No.</label>
              <div className="inputBox">
                <input
                  type="text"
                  name="Traveller"
                  className="input"
                  placeholder="Govt Id"
                  onChange={this.handleIdProof}
                  value={this.state.IdProof}
                  onBlur={this.onBlurIdProof}
                />
                <div className="buypasserr">
                  <small style={{ color: "white" }}>
                    {this.state.IdProofError}
                  </small>
                </div>
              </div>
            </div>
          </div>
          <div className="buypassagreement">
            <input
              type="checkbox"
              name="is_name"
              value={this.state.terms}
              checked={this.state.terms}
              onChange={this.handleTermsCheck}
            />
            <label className="check ">
              I have read and agree to the{" "}
              <span class="text-warning" onClick={() => this.tncModal()}>
                Terms &amp; Conditions
              </span>{" "}
              and Privacy Policy
              <div className="aguypasserrtnc">
                <small style={{ color: "white" }}>
                  {this.state.termsValidyError}
                </small>
              </div>
            </label>
          </div>

          <div className="row">
            <button
              type="button"
              className="btn btn-light searchbtn"
              onClick={this.onSubmit}
            >
              Add Traveller
            </button>
          </div>
        </form>

        {/* T&C Modal popup */}

        <Modal
          size="md"
          className="modal fade"
          onHide={this.closetnc}
          show={this.state.tncshow}
        >
          <Modal.Header closeButton className="modal-header modalheader">
            <h2 className="modal-title  text-center" id="exampleModalLongTitle">
              Term &amp; Conditions{" "}
            </h2>
          </Modal.Header>
          <Modal.Body className="modal-body pl-5 pr-5 text-center">
            <p> lorem </p>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
    userTableData: state.login.userTableData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onInitAgentTable: (userNameData) =>
      dispatch(loginActions.initAgentTable(userNameData)),
    // onSendTravelDetails: (travellerData) => dispatch(loginActions.sendTravellerDetails(travellerData))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(Searchcustomer));
