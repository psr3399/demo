import React, { Component } from "react";
import "./AddTraveller.css";

class AddTraveller extends Component {
  render() {
    return (
      <>
        <div className="container mt-5 mb-2">
          <h4 className="redtxt mb-4">Add Traveller Details</h4>
          <div className="row">
            <div className="col-md-1">
              <label>Title:</label>
              <div className="inputBox1 ">
                <select className="form-control form-control-sm">
                  <option>Mr</option>
                  <option>Ms</option>
                  <option>Mrs</option>
                </select>
              </div>
            </div>
            <div className="col-md-2">
              <label>First Name:</label>
              <div className="inputBox1 ">
                <input
                  type="text"
                  name="firstname"
                  className="input"
                  placeholder="Enter First Name"
                />
              </div>
            </div>
            <div className="col-md-2">
              <label>Last Name:</label>
              <div className="inputBox1 ">
                <input
                  type="text"
                  name="lastname"
                  className="input"
                  placeholder="Enter Last Name"
                />
              </div>
            </div>
            <div className="col-md-3">
              <label>Email Address:</label>
              <div className="inputBox1 ">
                <input
                  type="text"
                  name="email"
                  className="input"
                  placeholder="Enter Email Address"
                />
              </div>
            </div>
            <div className="col-md-3">
              <label>Mobile Number:</label>
              <div className="inputBox1 ">
                <input
                  type="text"
                  name="mobile"
                  className="input"
                  placeholder="Enter Mobile Number"
                />
              </div>
            </div>
            <div className="col-md-3">
              <label>Title:</label>
              <div className="inputBox1 ">
                <select className="form-control form-control-sm">
                  <option>Mr.</option>
                  <option>Ms.</option>
                  <option>Mrs.</option>
                </select>
              </div>
            </div>
            <div className="col-md-3">
              <label>
                GOVT ID <small>(Passport / PAN NO.)</small>:
              </label>
              <div className="inputBox1 ">
                <input
                  type="text"
                  name="govtid"
                  className="input"
                  placeholder="Enter GOVT ID"
                />
              </div>
            </div>
            <div className="col-md-3 offset-2">
              <button
                type="button"
                className="btn btn-danger btn-md float-right"
              >
                <i className="fa fa-user"></i> Add Traveller
              </button>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default AddTraveller;
