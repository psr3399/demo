import React, { Component } from "react";
import * as qs from "query-string";
import axios from "axios";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import NodeRSA from "node-rsa";
import tickmarkimg from "../../assets/images/tickfail.png";

class FailedTransaction extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    CustomerID: 0,
    PassType: "",
    ValidityMonths: "",
    Coupons: "",
    Amount: "",
    Leaflet_ID: "",
    CustomerName: "",
    MobileNumber: "",
    EmailAddress: "",
    PAN: "",
    PurchaseDate: "",
    ExpireDate: "",
    Status: "0",
    Title: "",
    ProofType: "",
    DOB: "1992-01-12",
    TransactionID: "",
    Remarks: "",
    AdditionalInfo: "",
    CreatedBy: "",
  };
  render() {
    return (
      <>
        <div className="container">
          <div className="row">
            <div className="col-md-12 text-center mt-5">
              <img
                src={tickmarkimg}
                className="img-fluid"
                style={{ width: "20%" }}
                alt=""
              />
            </div>

            <div className="col-md-12 text-center">
              <div className="thank-you-pop">
                <h1 className="text-danger mb-4 mt-2">
                  Sorry! {this.props.CustomerName}
                </h1>
                <p>Your payment got declined . Please try again </p>

                <table class="table table-responsive table-bordered mt-5">
                  <thead>
                    {/* <tr>
                      <th scope="col">flight Pass ID</th>
                      <th scope="col">Pass Type</th>
                      <th scope="col">Pass Count / Avalilable</th>
                      <th scope="col">VALIDITY</th>
                      <th scope="col">AMOUNT</th>
                      <th scope="col">STATUS</th>
                      <th scope="col">VALID TILL</th>
                    </tr> */}
                  </thead>
                  <tbody>
                    {/* <tr>
                      <th scope="row">SGSH6123</th>
                      <td>Short Haul</td>
                      <td>10/10</td>
                      <td>6 Months</td>
                      <td>72,000</td>
                      <td>Active</td>
                      <td>
                        30<sup>th</sup> June 2020
                      </td>
                    </tr> */}
                  </tbody>
                </table>

                {/* <button className="btn btn-danger mt-4 mb-4">
                  {" "}
                  <i className="fa fa-home"></i> &nbsp; Go to Dashboard{" "}
                </button> */}
              </div>
            </div>
          </div>
        </div>

        {/* <div className="modal fade" id="ignismyModal" role="dialog">
            <div className="modal-dialog text-center">
                <div className="modal-content">
                    <div className="modal-header">
                      <span className="imgalnmt"><img src="images/tickmark.png" className="img-fluid" style="width: 75%;" alt="" /></span>
                        <button type="button" className="close" data-dismiss="modal" aria-label=""><span>×</span></button>
                     </div>
					
                    <div className="modal-body">
                       
						
                         
                    </div>
					
                </div>
            </div>
        </div> */}
      </>
    );
  }
}

const mapStateToProps = (state) => {
  console.log("thank you state", state);
  let cust = JSON.parse(window.localStorage.getItem("FPVouchersReqData"));
  debugger;
  return {
    CustomerName: cust.CustomerName,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(FailedTransaction));
