import React, { Component } from "react";
import * as qs from "query-string";
import axios from "axios";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import NodeRSA from "node-rsa";
import tickmarkimg from "../../assets/images/tickmark.png";
import moment from "moment";
import Pdf from "react-to-pdf";

const ref = React.createRef();
const options = {
  orientation: "landscape",
  unit: "in",
  format: [900, 810],
};

class ThankYou extends Component {
  constructor(props) {
    super(props);
  }

  state = {
    CustomerID: 0,
    PassType: "",
    ValidityMonths: "",
    Coupons: "",
    Amount: "",
    Leaflet_ID: "",
    CustomerName: "",
    MobileNumber: "",
    EmailAddress: "",
    PAN: "",
    PurchaseDate: "",
    ExpireDate: "",
    Status: "0",
    Title: "",
    ProofType: "",
    DOB: "1992-01-12",
    TransactionID: "",
    Remarks: "",
    AdditionalInfo: "",
    CreatedBy: "",
  };
  gotodashboard = () => {
    console.log(" ia m here" + this.props.isLoggedIn);
    console.log(" ia m here2" + this.props.isLoggedInAgent);
    if (this.props.isLoggedIn) {
      this.props.history.push({
        pathname: "/flightpass",
      });
    } else if (this.props.isLoggedInAgent) {
      this.props.history.push({
        pathname: "/agentDashboard",
      });
    }
  };

  render() {
    const authData = JSON.parse(
      window.localStorage.getItem("FPVouchersReqData")
    );
    console.log("thankyou page", JSON.stringify(authData));
    console.log(authData.PassType);
    return (
      <div class="container text-right mt-5">
        <Pdf
          targetRef={ref}
          filename="FlightPassPurchase.pdf"
          options={options}
        >
          {({ toPdf }) => (
            <button class="btn btn-danger" onClick={toPdf}>
              {" "}
              <i class="fa fa-print"></i> &nbsp; Download PDF
            </button>
          )}
        </Pdf>
        <div className="container">
          <div className="row" ref={ref}>
            <div className="col-md-12 text-center mt-5 themebg">
              <img
                src={tickmarkimg}
                className="img-fluid"
                style={{ width: "15%", padding: "20px" }}
                alt=""
              />
            </div>

            <div className="col-md-12 text-center thnkborder">
              <div className="thank-you-pop">
                <h1 className="text-danger mb-4 mt-2">
                  Congratulations!{" "}
                  <span style={{ textTransform: "uppercase" }}>
                    {this.props.CustomerName}
                  </span>
                </h1>
                <p>Your have successfully purchased flight pass</p>
                <h3 className="cupon-pop">
                  <i className="fa fa-info-circle fa-3 infoicon"></i>
                  You will also receive an email shortly with details on your
                  registerd e-mail address
                </h3>

                <table className="table table-responsive table-bordered mt-5">
                  <thead>
                    <tr>
                      <th scope="col">NAME</th>
                      <th scope="col">PASS TYPE</th>
                      <th scope="col">FLIGHT COUNT </th>
                      <th scope="col">VALIDITY</th>
                      <th scope="col">AMOUNT / PASS</th>
                      {/* <th scope="col">STATUS</th> */}
                      <th scope="col">VALID TILL</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <th scope="row" className="text-uppercase">
                        {this.props.CustomerName}
                      </th>
                      <td>{authData.PassType}</td>
                      <td>
                        {authData.Coupons}/{authData.Coupons}
                      </td>
                      <td>{authData.ValidityMonths} Months</td>
                      <td>{authData.Amount}</td>
                      {/* <td>{authData.Status}</td> */}
                      <td>
                        {moment(authData.ExpireDate).format("DD-MMM-yyyy")}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-12 text-center">
              <button
                className="btn btn-danger mt-4 mb-4"
                onClick={this.gotodashboard}
              >
                <i className="fa fa-home"></i> &nbsp; Go to Dashboard
              </button>
              <button
                className="btn btn-danger mt-4 mb-4 ml-5"
                onClick={() =>
                  window.open(
                    "http://10.218.31.215:81/FlightPassRedeem/Login.aspx"
                  )
                }
              >
                &nbsp; Redeem Now!
              </button>
              <p>Login through SpiceClub for redeem your flights pass</p>
            </div>
          </div>
        </div>

        {/* <div className="modal fade" id="ignismyModal" role="dialog">
            <div className="modal-dialog text-center">
                <div className="modal-content">
                    <div className="modal-header">
                      <span className="imgalnmt"><img src="images/tickmark.png" className="img-fluid" style="width: 75%;" alt="" /></span>
                        <button type="button" className="close" data-dismiss="modal" aria-label=""><span>×</span></button>
                     </div>
					
                    <div className="modal-body">
                       
						
                         
                    </div>
					
                </div>
            </div>
        </div> */}
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log("thank you state", state);
  let cust = JSON.parse(window.localStorage.getItem("FPVouchersReqData"));
  debugger;
  return {
    CustomerName: cust.CustomerName,
    isLoggedIn: state.login.isLoggedIn,
    isLoggedInAgent: state.login.isLoggedInAgent,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(ThankYou));
