import React, { Component } from "react";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import * as JuspayActions from "../../store/actions/index";
import Container from "react-bootstrap/Container";

class JusPayRequest extends Component {
  constructor(props) {
    super(props);
    //this.scriptLoaded = this.scriptLoaded.bind(this);
  }
  render() {
    return (
      <div id="main">
        <div className="container">
          <div className="row">
            <div className="col-12 text-center payment-request pt-5 mt-5">
              <h1>Please wait while we redirect to payment</h1>
            </div>
          </div>
        </div>
      </div>
    );
  }

  componentDidMount() {
    const payload = this.props.payload;
    const baseOrder = this.props.baseOrder;
    const sign = this.props.signature;
    // console.log("pload", { payload });
    // console.log("sign", { sign });
    window.JusPayLoad({ payload }, { baseOrder }, { sign });
  }
}
const mapStateToProps = (state) => {
  // console.log("payload", state.juspay.payload);
  // console.log("baseOrder", state.juspay.baseOrder);
  // console.log("signature", state.juspay.signature);
  return {
    payload: state.juspay.payload,
    baseOrder: state.juspay.baseOrder,
    signature: state.juspay.signature,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onRequest: (payload, baseOrder, signature) =>
      dispatch(JuspayActions.onJusPayRequest(payload, baseOrder, signature)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JusPayRequest);
