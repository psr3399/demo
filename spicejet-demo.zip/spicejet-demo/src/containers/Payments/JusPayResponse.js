import React, { Component } from "react";
import * as qs from "query-string";
import axios from "axios";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import NodeRSA from "node-rsa";
import tickmarkimg from "../../assets/images/tickmark.png";
import * as JuspayActions from "../../store/actions/index";
import * as allUrls from '../../Constants/Constants'


class JusPayResponse extends Component {
  constructor(props) {
    super(props);

    // this.props.onRequest(
    //   this.state.payload,
    //   this.state.baseOrder,
    //   this.state.signature
    // );
  }
  state = {
    CustomerID: 0,
    PassType: "",
    ValidityMonths: "",
    Coupons: "",
    Amount: "",
    Leaflet_ID: "",
    CustomerName: "",
    MobileNumber: "",
    EmailAddress: "",
    PAN: "",
    PurchaseDate: "",
    ExpireDate: "",
    Status: "0",
    Title: "",
    ProofType: "",
    DOB: "1992-01-12",
    TransactionID: "",
    Remarks: "",
    AdditionalInfo: "",
    CreatedBy: "",
  };
  render() {
    return (
      <>
        <div id="main" style={{ minheight: "600px" }}>
          <div className="container">
            <div className="row">
              <div className="col-md-12 text-center mt-5">
                <img
                  src={tickmarkimg}
                  className="img-fluid"
                  style={{ width: "20%" }}
                  alt=""
                />
              </div>

              <div className="col-md-12 text-center">
                <div className="thank-you-pop">
                  <h1 className="text-danger mb-4 mt-2">
                    Congratulations! {this.state.CustomerName}
                  </h1>
                  <p>Your have successfully purchased flight pass</p>
                  <h3 className="cupon-pop">
                    You will also receive an email shortly with details on your
                    registerd e-mail address
                  </h3>

                  <table className="table table-responsive table-bordered mt-5">
                    <thead>
                      {/* <tr>
                      <th scope="col">flight Pass ID</th>
                      <th scope="col">Pass Type</th>
                      <th scope="col">Pass Count / Avalilable</th>
                      <th scope="col">VALIDITY</th>
                      <th scope="col">AMOUNT</th>
                      <th scope="col">STATUS</th>
                      <th scope="col">VALID TILL</th>
                    </tr> */}
                    </thead>
                    <tbody>
                      {/* <tr>
                      <th scope="row">SGSH6123</th>
                      <td>Short Haul</td>
                      <td>10/10</td>
                      <td>6 Months</td>
                      <td>72,000</td>
                      <td>Active</td>
                      <td>
                        30<sup>th</sup> June 2020
                      </td>
                    </tr> */}
                    </tbody>
                  </table>

                  {/* <button className="btn btn-danger mt-4 mb-4">
                  {" "}
                  <i className="fa fa-home"></i> &nbsp; Go to Dashboard{" "}
                </button> */}
                </div>
              </div>
            </div>
          </div>

          {/* <div className="modal fade" id="ignismyModal" role="dialog">
            <div className="modal-dialog text-center">
                <div className="modal-content">
                    <div className="modal-header">
                      <span className="imgalnmt"><img src="images/tickmark.png" className="img-fluid" style="width: 75%;" alt="" /></span>
                        <button type="button" className="close" data-dismiss="modal" aria-label=""><span>×</span></button>
                     </div>
					
                    <div className="modal-body">
                       
						
                         
                    </div>
					
                </div>
            </div>
        </div> */}
        </div>
      </>
    );
  }

  componentDidMount() {
    debugger;
    let flag = true;
    let authData = "";
    authData = JSON.parse(window.localStorage.getItem("FPVouchersReqData"));
    if (window.location.search != "") {
      const params = qs.parse(window.location.search);
      // const encyptKey = new NodeRSA(
      //   "-----BEGIN RSA PRIVATE KEY-----MIIEpQIBAAKCAQEA2R+5+b1HZSNNMotnr7Z/5By4NSTZW4dDMGDy2huOSLn1EF6v75sssdY5kRkFoihLIeNQA+yzsi0kzpz3rCCCmo1DJwgoqA48JVQwwBjZ9SHeC0nE66VODmMJJGNWe1quHWQb3otIzS+U+rtd1Alzo9up8u8e+FrecyjO6fBMZfd32iO7qPtExtA1XDtKMqoRbHMiAz940xA5+BLmJC+gp1IYsVce2KA5BW1laPxbku42aQR7eZipSa3BYRY8m964Aj6vLj4kTeTbrc4OH7yatRdWbVbrwVWpg936g8Q3Qf3jQY+HMu76l1WeXK4GkPkA+oJXY6ag1XhhqtOrLw3rJwIDAQABAoIBAQCjy2thG4lgouD54HC3/dU9IO1WKhZPFht5w6lxIJiWBLL7RnMzLrzo69NBwr6dNgh36CPU0hw9rhC2TXQKRfxA25BtQZpqLVLyVjDwuc6zPnljyqLjojDgaZXb/ZSgOihfw8XCfRDOubaJ8A84hmjWlEABJKMYeHSYK5Dsqnr37/Oj4OT2NWLaRx8Kk0HPuv/bxx3MHurIHRtG514UJZcOfN8Ti69/DoYbtb/Mpg/djXr5s47TafxPa8jyT2E8nWboPvYPDQcdu2CIE0mbrj2C0Ak7g20ZYzm9HCbJHVG+2rPSjVgXKW2ZgXoZflte+G5vRfDrZH+TZuo+ja0pVlIBAoGBAP4ZEtdpRJp5kvj7bUIkXd5E6lrxd2M0VprfMhHk0i+Z1p1nF8StF6p9uIGuRIEthvdRZVy56fWCHXOfmquRJDHazQZVnnXcRaqhuMYdZoJ3i1KkmSL4X/SdBsB4rY4FQZWNtwKoSeDugQeJzf4bhyn0iZGbWPq+XO70MxXya8CfAoGBANq/zL6ul+G6i/nXrfzwUr83EtXh6Zoj51YBK4g3ZIIuWkWvbo9NguV3p9KmeRKMWwYORHC7aVwpHdjzOyzmSFdmC+5dqVe6rkdl9AzxpKt0p0rOznmZUhDcdElCk0p6pC5RQDAt2PA4aR3kT+9z2dPV0IHsUGiouF/LtmTmdCB5AoGAIShUdRefhCjpLORiVYc5WI/VpRhtY9yokH0fo4Ygh2Wjw9Z4G4oa1HyjXwjGl7TBL/THLVp1VTwta7EgFdNSzc6ngnQZwXeE/8cqvW+IuO2wmJAyC4Ytv1XeU69rtmSpMkLT5tzfByMYY0twPgCJmsf2S7Hh4paEugnTwMFpnjECgYEAoTqc/i5RY97LLOr7ImM/mhBNobdRJnswFwPlwhCR1CG2B4a2Rokq4VbAK1LoCfPJYz1A1JZNoc/sX+tmwkE5MLHWOWpvVmoR6i4LIz83z+e7JjgnlxialDLowtZ/GXYrbLgWR2yDaQsq7w1InYUWGDyP4jL7USiKPJE5bkUtcoECgYEAwhbb1NxzteIr8zlytMj52sgeiJPQRjbU5CoMAJuiHvYHT8jQwso7lfbz+fXdQamU29v1Hdhc2JR1xWxrTz4bAt1l9lWK8zQBTK3SOlhyvrvNkKtTwjansR6+uwB9KY5mrF++pRA8IL2f0yhx2uqwDkX/Og6ZnFHJn3BvQM/DWPg=-----END RSA PRIVATE KEY-----"
      // );
      // const result = encyptKey.decrypt(params.signature, "buffer", "json");
      console.log(params);
      //let paylo = window.localStorage.getItem("FPVouchersReqData");
      if (params.status == "CHARGED") {
      } else {
        flag = false;
      }
    }
    if (authData.PAN === null) {
      authData.PAN = "NoPAN";
    }
    console.log("Request", JSON.stringify(authData));
    if (flag) {
      const res = axios
        .post(
          allUrls.createFlightPassUrl,
          authData
        )
        .then((res) => {
          console.log("getamount", res.data);
          //this.props.onRequest(this.state.CustomerName);
          this.setState({ CustomerName: authData.CustomerName });
          this.props.history.push({
            pathname: "/ThankYou",
          });
        });
    } else {
      this.setState({ CustomerName: authData.CustomerName });
      this.props.history.push({
        pathname: "/FailedTransaction",
      });
    }
  }
}

// const authData = {
//   CustomerID: 0,
//   PassType: passType,
//   ValidityMonths: months,
//   Coupons: coupons,
//   Amount: amount,
//   Leaflet_ID: "",
//   CustomerName: customerName,
//   MobileNumber: mobileNumber,
//   EmailAddress: emailAddress,
//   PAN: pan,
//   PurchaseDate: CurrentDate,
//   ExpireDate: purchaseDate,
//   Status: "0",
//   Title: title,
//   ProofType: ProofType,
//   DOB: "1992-01-12",
//   TransactionID: transactionID,
//   Remarks: "",
//   AdditionalInfo: "",
//   CreatedBy: createdBy,
// };

const mapStateToProps = (state) => {
  console.log("response state", state);
  debugger;
  return {
    payload: state.juspay.payload,
    baseOrder: state.juspay.baseOrder,
    signature: state.juspay.signature,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    // onRequest: (CustomerName) =>
    //   dispatch(JuspayActions.onThankYou(CustomerName)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(JusPayResponse));
