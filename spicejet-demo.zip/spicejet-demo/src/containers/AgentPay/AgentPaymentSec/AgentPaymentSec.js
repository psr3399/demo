import React, { Component } from "react";
import "./AgentPaymentSec.css";
import axios from "axios";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { button, Modal } from "react-bootstrap";
import * as JuspayActions from "../../../store/actions/index";
import NodeRSA from "node-rsa";
import * as allUrls from "../../../Constants/Constants";
import moment from "moment";
class AgentPaymentSec extends Component {
  constructor(props) {
    super(props);
    this.onClickHandler = this.onClickHandler.bind(this);
    this.handleTermsCheck = this.handleTermsCheck.bind(this);
    this.onPaymentOptionChange = this.onPaymentOptionChange.bind(this);
    this.onValueChange = this.onValueChange.bind(this);
    this.handlePassType = this.handlePassType.bind(this);
    this.handleValidity = this.handleValidity.bind(this);
    this.handlePassCount = this.handlePassCount.bind(this);
  }
  state = {
    terms: true,
    AgentBalance: 0,
    paymentMode: "AGMode",
    selectedPax: {},
    payload: {},
    baseOrder: {},
    signature: "",
    PassType: "All Flights",
    PassValidity: "",
    PassCount: "",
    PassAmount: "",
    terms: false,
    entrypointid: "main",
    action: "payment_page",
    merchantId: "websiteuser",
    clientId: "websiteuser_web",
    merchantKeyId: "3388",
    environment: "sandbox",
    orderID: Date.now().toString(),
    first_name: this.props.details.Title,
    last_name: this.props.details.FullName,
    mobileNumber: this.props.details.UserName,
    emailAddress: this.props.details.EmailID,
    customerId: this.props.details.UserName,
    AmountPerPass: "",
    passTypeError: "",
    passCountError: "",
    passValidityError: "",
    passAmountError: "",
    termsValidyError: "",
    tncshow: false,
    PerPassAmount: "",
  };

  tncModal() {
    this.setState({ tncshow: true });
  }
  closetnc = () => {
    this.setState({ tncshow: false });
  };
  handleTermsCheck(e) {
    var termsVal = !this.state.terms;
    this.setState({ terms: termsVal });
  }
  handlePassType(e) {
    console.log("handlePassType", e.target.value);
    this.setState({
      PassType: e.target.value,
      PassValidity: "",
      PassCount: "",
      PassAmount: "",
    });
  }
  handleValidity(e) {
    console.log("handleValidity", e.target.value);
    this.setState({
      PassValidity: e.target.value,
      PassCount: "",
      PassAmount: "",
    });
  }
  handlePassCount(e) {
    console.log("handlePassCount", e.target.value);
    let pcount = e.target.value;
    this.setState({ PassCount: e.target.value });
    var buypassData = {
      PassType: this.state.PassType,
      Months: this.state.PassValidity,
      Coupons: pcount == "" ? 0 : pcount,
      Amount: 0,
    };
    //if (pcount != "") {
    axios
      .post(allUrls.passAmountUrl, buypassData)
      .then((res) => {
        // console.log("getamount", res.data.PassType);
        debugger;
        this.setState({
          AmountPerPass: res.data.Amount.toFixed(2),
          PassAmount: (res.data.Amount * this.state.PassCount).toFixed(2),
          PerPassAmount: res.data.Amount,
        });
      })
      .catch((error) => {
        this.setState({
          PassAmount: "",
          AmountPerPass: "",
        });
      });
    // }
  }
  componentDidMount() {
    console.log("AgentPaymentSec", this.props);
    const agentName = "TESTMKT001";
    const res = axios.get(allUrls.getAccountBalUrl + agentName).then((res) => {
      console.log("AgentBalance getamount", res.data);
      this.setState({ AgentBalance: res.data });
    });
  }

  render() {
    console.log(
      "data sljfls",
      this.state.PassType,
      this.state.PassValidity,
      this.state.PassCount,
      this.state.PassAmount,
      this.props.selectedPax
    );
    return (
      <>
        <div className="col-md-8">
          <div className="agpurchase">
            <h4 className="text-white mb-4">Buy New Flight Pass</h4>
            <div className="row">
              <div className="col-md-6">
                <label className="text-white">CHOOSE PASS TYPE:</label>
                <div className="inputBox ">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handlePassType}
                  >
                    <option value="">Select</option>
                    <option value="All Flights" selected>
                      All Flights
                    </option>
                    <option value="Short Haul">Short Haul</option>
                    {/*<option value="Long Haul">Long Haul</option> */}
                  </select>
                  <div className="agpayerror">
                    <small style={{ color: "#fff" }}>
                      {this.state.passTypeError}
                    </small>
                  </div>
                </div>
              </div>

              <div className="col-md-6" onChange={this.handleValidity}>
                <label className="text-white">CHOOSE VALIDITY:</label>
                <div className="inputBox ">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handleValidity}
                    value={this.state.PassValidity}
                  >
                    <option value="">Select</option>

                    <option value="3">3 Months</option>
                    <option value="6">6 Months</option>
                    <option value="12">12 Months</option>
                  </select>
                  <div className="agpayerror">
                    <small style={{ color: "#fff" }}>
                      {this.state.passValidityError}
                    </small>
                  </div>
                </div>
              </div>
              <div className="col-md-6" onChange={this.handlePassCount}>
                <label className="text-uppercase text-white">
                  Choose No. of Flights:
                </label>
                <div className="inputBox ">
                  <select
                    className="form-control form-control-sm"
                    value={this.state.PassCount}
                  >
                    <option value="">Select</option>
                    <option value="5">05</option>
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select>
                  <div className="agpayerror">
                    <small style={{ color: "#fff" }}>
                      {this.state.passCountError}
                    </small>
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <label className="text-white">AMOUNT:</label>
                <div className="inputBox ">
                  <input
                    type="text"
                    className="input"
                    value={this.state.PassAmount}
                    onChange={this.handleAmount}
                    disabled={true}
                  />
                  <small className="perflight">
                    Per Flight Price : {this.state.PerPassAmount}
                  </small>
                  <small style={{ color: "#fff" }}>
                    {this.state.passAmountError}
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-4 searchbox p-4">
          <h4 className="text-white">Payment option</h4>
          <div className="paymodchk">
            <div
              className="d-flex bd-highlight"
              onChange={this.onPaymentOptionChange}
            >
              <div className="p-2 flex-fill bd-highlight">
                <label className="radio">
                  AG Mode
                  <input
                    type="radio"
                    checked="checked"
                    name="is_company"
                    value="AGMode"
                    checked={this.state.paymentMode === "AGMode"}
                  />
                  <span className="checkround"></span>
                </label>
              </div>
              <div className="p-2 flex-fill bd-highlight">
                <label className="radio">
                  Juspay
                  <input
                    type="radio"
                    name="is_company"
                    value="JusPay"
                    checked={this.state.paymentMode === "JusPay"}
                  />
                  <span className="checkround"></span>
                </label>
              </div>
            </div>
            <hr />
            <div className="baldetail" id="AGMode">
              <p>Balance Amount :</p>
              <p className="text-danger pb-4">
                <strong>{this.state.AgentBalance}</strong>
              </p>
            </div>
          </div>
          <hr className="whitedevider"></hr>
          <h4 className="text-white">Price Details</h4>
          {/* <hr className="whitedevider"></hr> */}
          <span className="text-white">
            {this.state.PassType ? this.state.PassType : ""}
          </span>
          <span className="text-white float-right">
            {" "}
            {this.state.PassAmount}
          </span>
          <hr className="whitedevider"></hr>
          <h5 className="text-white float-left">Total Amount</h5>
          <h5 className="text-white float-right">
            INR {this.state.PassAmount}
          </h5>
          <div className="agreement mb-4">
            <input
              type="checkbox"
              name="is_name"
              value={this.state.terms}
              onChange={this.handleTermsCheck}
            />
            <label className="check ">
              I have read and agree to the{" "}
              <span class="text-warning" onClick={() => this.tncModal()}>
                Terms &amp; Conditions
              </span>{" "}
              and Privacy Policy <br />
            </label>
            <small style={{ color: "white" }}>
              {this.state.termsValidyError}
            </small>
          </div>
          <button
            type="button"
            className="btn btn-lg btn-block conf2pay mb-4"
            onClick={this.onClickHandler}
          >
            Confirm The Payment
          </button>
        </div>

        {/* T&C Modal popup */}

        <Modal
          size="md"
          className="modal fade"
          onHide={this.closetnc}
          show={this.state.tncshow}
        >
          <Modal.Header closeButton className="modal-header modalheader">
            <h2 className="modal-title  text-center" id="exampleModalLongTitle">
              Term &amp; Conditions{" "}
            </h2>
          </Modal.Header>
          <Modal.Body className="modal-body pl-5 pr-5 text-center">
            <p> lorem </p>
          </Modal.Body>
        </Modal>
      </>
    );
  }
  inputValidation = () => {
    console.log("amount", this.state.PassAmount);
    if (this.state.PassType == "") {
      this.setState({ passTypeError: "*Required" });
      return false;
    } else {
      this.setState({ passTypeError: "" });
    }
    if (this.state.PassValidity == "") {
      this.setState({ passValidityError: "*Required" });
      return false;
    } else {
      this.setState({ passValidityError: "" });
    }
    if (this.state.PassCount == "") {
      console.log("inside count");
      this.setState({ passCountError: "*Required" });
      return false;
    } else {
      this.setState({ passCountError: "" });
    }

    // if (!parseInt(this.state.PassAmount) > 0) {
    //   this.setState({ passAmountError: "*Required" });
    //   return false;
    // }
    if (!this.state.terms) {
      this.setState({ termsValidyError: "*Please accept Terms and Condition" });
      return false;
    }

    return true;
  };

  onClickHandler(e) {
    let flg = this.inputValidation();
    if (flg) {
      console.log("Validationr", flg);
      console.log("test onClickHandler", this.state.terms);
      console.log("test paymentMode", this.props.details);
      console.log("test PassAmount", this.state.PassAmount);
      console.log("test selectedPax", this.props.selectedPax);
      const agentID = this.props.details.UserName;
      const ACCNTID = "";
      const totalAmt = "1.00";
      const currencyCode = "INR";
      const txnID = Date.now().toString();
      const AGACCNTReq = {
        MobileOrEmail: { agentID },
      };
      if (this.state.paymentMode === "AGMode") {
        debugger;
        axios
          .post(allUrls.getAgAccountIdUrl, JSON.stringify(AGACCNTReq))
          .then((res) => {
            console.log("getAGAccountID", res.data);
            ACCNTID = res.data;
          });
        let agRequest = {
          NRCURRENCYCODE: currencyCode,
          NRAMOUNT: totalAmt,
          NRAGENCID: agentID,
          ACCOUNTID: ACCNTID,
          NRAMOUNTUPLOADED: totalAmt,
        };
        axios.post(allUrls.agentPaymentResponseUrl, agRequest).then((res) => {
          console.log("AGPaymentResponse", res.data);
          const agBal = this.state.AgentBalance.split(" ");
          const balanceAmount = parseInt(agBal) - parseInt(totalAmt);
          axios
            .post(
              allUrls.insertSubagentUrl +
                agentID +
                "&&TransactionAmount=" +
                totalAmt +
                "&&BalanceAmount=" +
                balanceAmount +
                "&&TransactionID=" +
                txnID
            )
            .then((res) => {
              console.log("InsertSubAgentTransaction", res.data);
              debugger;
              this.currentDate = new Date();
              this.FPVouchersReqData = {
                CustomerID: this.state.customerId,
                PassType: this.state.PassType,
                ValidityMonths: this.state.PassValidity,
                Coupons: this.state.PassCount,
                Amount: this.state.AmountPerPass,
                Leaflet_ID: 0,
                CustomerName: this.props.selectedPax.CustomerName,
                MobileNumber: this.props.selectedPax.MobileNumber,
                EmailAddress: this.props.selectedPax.EmailAddress,
                PAN: this.props.details.PAN,
                PurchaseDate: new Date(),
                ExpireDate: new Date().addMonths(this.props.PassCount),
                Status: 0,
                Title: this.props.details.Title,
                ProofType: "PAN",
                DOB: this.props.details.DOB,
                TransactionID: this.state.orderID,
                Remarks: "",
                AdditionalInfo: "",
                CreatedBy: this.state.customerId,
              };
              console.log("FPVouchersReqData" + this.FPVouchersReqData);
              window.localStorage.setItem(
                "FPVouchersReqData",
                JSON.stringify(this.FPVouchersReqData)
              );

              this.props.history.push("/JusPayResponse");
            });
        });
      } else {
        // Juspay Integration
        debugger;
        console.log("Juspay Integration start ");
        this.baseOrder = {
          order_id: this.state.orderID,
          timestamp: this.state.orderID,
          first_name: this.state.first_name,
          last_name: this.state.last_name,
          amount: this.state.PassAmount,
          customer_id: this.state.customerId,
          customer_phone: this.state.customerId,
          customer_email: this.state.emailAddress,
          merchant_id: this.state.merchantId,
          return_url: allUrls.returnUrl,
          //return_url: "http://10.218.31.215:8000/JusPayResponse",
        };
        console.log("enter in orders ");
        //const payload = JSON.stringify(this.baseOrder); //new Order(JSON.stringify(baseOrder));
        const pay = JSON.stringify(this.baseOrder);
        //console.log("order info:" + payload);
        const encyptKey = new NodeRSA(
          "-----BEGIN RSA PRIVATE KEY-----MIIEpQIBAAKCAQEA2R+5+b1HZSNNMotnr7Z/5By4NSTZW4dDMGDy2huOSLn1EF6v75sssdY5kRkFoihLIeNQA+yzsi0kzpz3rCCCmo1DJwgoqA48JVQwwBjZ9SHeC0nE66VODmMJJGNWe1quHWQb3otIzS+U+rtd1Alzo9up8u8e+FrecyjO6fBMZfd32iO7qPtExtA1XDtKMqoRbHMiAz940xA5+BLmJC+gp1IYsVce2KA5BW1laPxbku42aQR7eZipSa3BYRY8m964Aj6vLj4kTeTbrc4OH7yatRdWbVbrwVWpg936g8Q3Qf3jQY+HMu76l1WeXK4GkPkA+oJXY6ag1XhhqtOrLw3rJwIDAQABAoIBAQCjy2thG4lgouD54HC3/dU9IO1WKhZPFht5w6lxIJiWBLL7RnMzLrzo69NBwr6dNgh36CPU0hw9rhC2TXQKRfxA25BtQZpqLVLyVjDwuc6zPnljyqLjojDgaZXb/ZSgOihfw8XCfRDOubaJ8A84hmjWlEABJKMYeHSYK5Dsqnr37/Oj4OT2NWLaRx8Kk0HPuv/bxx3MHurIHRtG514UJZcOfN8Ti69/DoYbtb/Mpg/djXr5s47TafxPa8jyT2E8nWboPvYPDQcdu2CIE0mbrj2C0Ak7g20ZYzm9HCbJHVG+2rPSjVgXKW2ZgXoZflte+G5vRfDrZH+TZuo+ja0pVlIBAoGBAP4ZEtdpRJp5kvj7bUIkXd5E6lrxd2M0VprfMhHk0i+Z1p1nF8StF6p9uIGuRIEthvdRZVy56fWCHXOfmquRJDHazQZVnnXcRaqhuMYdZoJ3i1KkmSL4X/SdBsB4rY4FQZWNtwKoSeDugQeJzf4bhyn0iZGbWPq+XO70MxXya8CfAoGBANq/zL6ul+G6i/nXrfzwUr83EtXh6Zoj51YBK4g3ZIIuWkWvbo9NguV3p9KmeRKMWwYORHC7aVwpHdjzOyzmSFdmC+5dqVe6rkdl9AzxpKt0p0rOznmZUhDcdElCk0p6pC5RQDAt2PA4aR3kT+9z2dPV0IHsUGiouF/LtmTmdCB5AoGAIShUdRefhCjpLORiVYc5WI/VpRhtY9yokH0fo4Ygh2Wjw9Z4G4oa1HyjXwjGl7TBL/THLVp1VTwta7EgFdNSzc6ngnQZwXeE/8cqvW+IuO2wmJAyC4Ytv1XeU69rtmSpMkLT5tzfByMYY0twPgCJmsf2S7Hh4paEugnTwMFpnjECgYEAoTqc/i5RY97LLOr7ImM/mhBNobdRJnswFwPlwhCR1CG2B4a2Rokq4VbAK1LoCfPJYz1A1JZNoc/sX+tmwkE5MLHWOWpvVmoR6i4LIz83z+e7JjgnlxialDLowtZ/GXYrbLgWR2yDaQsq7w1InYUWGDyP4jL7USiKPJE5bkUtcoECgYEAwhbb1NxzteIr8zlytMj52sgeiJPQRjbU5CoMAJuiHvYHT8jQwso7lfbz+fXdQamU29v1Hdhc2JR1xWxrTz4bAt1l9lWK8zQBTK3SOlhyvrvNkKtTwjansR6+uwB9KY5mrF++pRA8IL2f0yhx2uqwDkX/Og6ZnFHJn3BvQM/DWPg=-----END RSA PRIVATE KEY-----"
        );
        const result = encyptKey.sign(pay, "base64", "utf8");
        //res.json({ message: result });
        console.log("singg", result);
        this.setState({ signature: result });

        this.payload = {
          action: this.state.action,
          merchantId: this.state.merchantId,
          orderId: this.state.orderID,
          amount: this.state.PassAmount,
          customerId: this.state.customerId,
          endUrls: this.baseOrder.return_url,
          orderDetails: JSON.stringify(this.baseOrder),
          environment: this.state.environment,
          merchantKeyId: this.state.merchantKeyId,
          client_id: this.state.clientId,
          entry_point_id: this.state.entrypointid, //Iframe will load inside div with id='main'
          signature: result,
        };

        // this.setState({ payload: this.payload });
        // this.setState({ baseOrder: this.baseOrder });
        // this.setState({ signature: this.state.signature });
        this.props.onRequest(this.payload, this.baseOrder, result);
        debugger;
        this.currentDate = new Date();
        this.FPVouchersReqData = {
          CustomerID: this.state.customerId,
          PassType: this.state.PassType,
          ValidityMonths: this.state.PassValidity,
          Coupons: this.state.PassCount,
          Amount: this.state.AmountPerPass,
          Leaflet_ID: 0,
          CustomerName: this.props.selectedPax.CustomerName,
          MobileNumber: this.props.selectedPax.MobileNumber,
          EmailAddress: this.props.selectedPax.EmailAddress,
          PAN: this.props.details.PAN,
          PurchaseDate: new Date(),
          ExpireDate: moment().add(this.state.PassValidity, "M"),
          Status: 0,
          Title: this.props.details.Title,
          ProofType: "PAN",
          DOB: this.props.details.DOB,
          TransactionID: this.state.orderID,
          Remarks: "",
          AdditionalInfo: "",
          CreatedBy: this.state.customerId,
        };
        window.localStorage.setItem(
          "FPVouchersReqData",
          JSON.stringify(this.FPVouchersReqData)
        );
        this.props.history.push("/JusPayRequest");
      }
    }
  }
  handleTermsCheck(e) {
    var termsVal = !this.state.terms;
    this.setState({ terms: termsVal });
    console.log("test onClickHandler", termsVal);
  }
  onPaymentOptionChange(e) {
    console.log("onPaymentOptionChange", e.target.value);
    this.setState({ paymentMode: e.target.value });
  }
  onValueChange(event) {
    // this.setState({
    //   paymentMode: event.target.value,
    // });
  }
}

const mapStateToProps = (state) => {
  debugger;
  return {
    loading: state.login.loading,
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
    // PassType: state.juspay.PassType,
    // PassValidity: state.juspay.PassValidity,
    // PassCount: state.juspay.PassCount,
    // PassAmount: state.juspay.PassAmount,
    // AmountPerPass: state.juspay.AmountPerPass,
    selectedPax: state.login.selectedPassenger,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onRequest: (payload, baseOrder, signature) =>
      dispatch(JuspayActions.onJusPayRequest(payload, baseOrder, signature)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentPaymentSec));
