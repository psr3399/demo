import React, { Component } from "react";
import "./AgentInfoPassDetails.css";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import moment from "moment";

class AgentInfoPassDetails extends Component {
  constructor(props){
  super(props);
  this.state = {
   DOBChange : moment(this.props.selectedPassenger.DOB).format("DD/MM/YYYY")
  };
  }

  // componentWillMount(){}
  // componentDidMount(){}
  // componentWillUnmount(){}

  // componentWillReceiveProps(){}
  // shouldComponentUpdate(){}
  // componentWillUpdate(){}
  // componentDidUpdate(){}

  render() {
    console.log(" from psdetails" + this.props.selectedPassenger);
    return (
      <div className="col-md-12 mt-4">
        <h4 className="redtxt mb-4">Passenger Details</h4>
        <div className="memberpassdetail p-3">
          <span className="pr-4 text-uppercase">
            Name : {this.props.selectedPassenger.Title}{" "} {this.props.selectedPassenger.CustomerName}{" "}
          </span>{" "}
          <span className="pr-4">
            Mobile : {this.props.selectedPassenger.MobileNumber}{" "}
          </span>{" "}
          <span className="pr-4">
            Email : {this.props.selectedPassenger.EmailAddress}{" "}
          </span>{" "}
          <span className="pr-4">
            {" "}
            DOB: {this.state.DOBChange}{" "} 
          </span>
          <span className="pr-4">
            {" "}
            GOVT ID: {this.props.selectedPassenger.ProofType}{" - "} {this.props.selectedPassenger.PANCard}{" "} 
          </span>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  console.log("state.login.selectedPassenger", state.login.selectedPassenger);
  console.log("state.login.isLoggedInAgent", state.login.isLoggedInAgent);
  return {
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
    tableData: state.login.tableData,
    selectedPassenger: state.login.selectedPassenger,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentInfoPassDetails));
