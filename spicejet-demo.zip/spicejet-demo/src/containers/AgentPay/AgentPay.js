import React, { Component } from "react";
import Auxiliary from "../../hoc/Auxiliary/Auxiliary";
import AgentInfo from "../AgentDashboard/AgentInfo/AgentInfo";
import AgentInfoPassDetails from "./AgentInfoPassDetails/AgentInfoPassDetails";
import AgentPaymentSec from "./AgentPaymentSec/AgentPaymentSec";
import AgentBuynowSec from "./AgentBuynowSec/AgentBuynowSec";
import { connect } from "react-redux";
import { withRouter } from "react-router";

class AgentPay extends Component {
  render() {
    return (
      <Auxiliary>
        <div className="container-fluid dullredbg">
          <div className="container">
            <div className="row">
              <div className="col-md-6 pt-5">{<AgentInfo />}</div>
              <AgentInfoPassDetails userData={this.props.details} />
            </div>
          </div>
        </div>

        <div className="container mb-5">
          <div className="row">
            {/* <AgentBuynowSec /> */}
            <AgentPaymentSec />
          </div>
        </div>
      </Auxiliary>
    );
  }

  componentDidMount() {
    console.log("tset", this.props.details);
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.login.loading,
    details: state.login.userData,
    isLoggedInAgent: state.login.isLoggedInAgent,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentPay));
