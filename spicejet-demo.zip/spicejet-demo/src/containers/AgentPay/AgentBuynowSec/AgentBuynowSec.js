import React, { Component } from "react";
import "./AgentBuynowSec.css";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import axios from "axios";
import * as loginActions from "../../../store/actions/index";
import * as allUrls from '../../../Constants/Constants'


class AgentBuynowSec extends Component {
  constructor(props) {
    super(props);
    this.handlePassType = this.handlePassType.bind(this);
    this.handleValidity = this.handleValidity.bind(this);
    this.handlePassCount = this.handlePassCount.bind(this);
    // this.handleAmount = this.handleAmount.bind(this);
    //this.handleTermsCheck = this.handleTermsCheck.bind(this);
  }

  render() {
    return (
      <>
        <div className="col-md-8">
          <div className="agpurchase">
            <h4 className="redtxt mb-4">Buy New Flight Pass</h4>
            <div className="row">
              <div className="col-md-6">
                <label>CHOOSE PASS TYPE:</label>
                <div className="inputBox1 ">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handlePassType}
                  >
                    <option value="">Select</option>
                    <option value="All Flights">All Flights</option>
                     <option value="Short Haul">Short Haul</option>
                    {/*<option value="Long Haul">Long Haul</option> */}
                  </select>
                  <small style={{ color: "white" }}>
                    {this.state.passTypeError}
                  </small>
                </div>
              </div>

              <div className="col-md-6" onChange={this.handleValidity}>
                <label>CHOOSE VALIDITY:</label>
                <div className="inputBox1 ">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handleValidity}
                  >
                    <option value="">Select</option>
                    {/* <option value="3">3 Months</option> */}
                    <option value="6">6 Months</option>
                    <option value="12">12 Months</option>
                  </select>
                  <small style={{ color: "white" }}>
                    {this.state.passValidityError}
                  </small>
                </div>
              </div>
              <div className="col-md-6" onChange={this.handlePassCount}>
                <label>CHOOSE PASS COUNT:</label>
                <div className="inputBox1 ">
                  <select className="form-control form-control-sm">
                    <option value="">Select</option>
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                  </select>
                  <small style={{ color: "white" }}>
                    {this.state.passCountError}
                  </small>
                </div>
              </div>

              <div className="col-md-6">
                <label>AMOUNT:</label>
                <div className="inputBox1 ">
                  <input
                    type="text"
                    className="input"
                    value={this.state.PassAmount}
                    onChange={this.handleAmount}
                    disabled={true}
                  />
                  <small style={{ color: "white" }}>
                    {this.state.passAmountError}
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }

  state = {
    payload: {},
    baseOrder: {},
    signature: "",
    PassType: "",
    PassValidity: "",
    PassCount: "",
    PassAmount: "",
    terms: false,
    entrypointid: "main",
    action: "payment_page",
    merchantId: "websiteuser",
    clientId: "websiteuser_web",
    merchantKeyId: "3388",
    environment: "sandbox",
    orderID: Date.now().toString(),
    first_name: this.props.userData.Title,
    last_name: this.props.userData.FullName,
    mobileNumber: this.props.userData.UserName,
    emailAddress: this.props.userData.EmailID,
    customerId: this.props.userData.UserName,
    passTypeError: "",
    passCountError: "",
    passValidityError: "",
    passAmountError: "",
    termsValidyError: "",
    amountPerPass: "0",
  };
  handleTermsCheck(e) {
    var termsVal = !this.state.terms;
    this.setState({ terms: termsVal });
  }
  handlePassType(e) {
    console.log("handlePassType", e.target.value);
    this.setState({ PassType: e.target.value });
  }
  handleValidity(e) {
    console.log("handleValidity", e.target.value);
    this.setState({ PassValidity: e.target.value });
  }
  handlePassCount(e) {
    debugger;
    console.log("handlePassCount", e.target.value);
    let pcount = e.target.value;
    console.log("null", pcount == null);
    console.log("empty", pcount == " ");
    this.setState({ PassCount: e.target.value });

    var buypassData = {
      PassType: this.state.PassType,
      Months: this.state.PassValidity,
      Coupons: pcount == "" ? 0 : pcount,
      Amount: 0,
    };

    axios
      .post(allUrls.passAmountUrl, buypassData)
      .then((res) => {
        // console.log("getamount", res.data.PassType);
        debugger;
        this.setState({
          amountPerPass: res.data.Amount.toFixed(2),
        });
        this.setState({
          PassAmount: (res.data.Amount * this.state.PassCount).toFixed(2),
        });
        this.props.onAddPayDetails(
          this.state.PassType,
          this.state.PassValidity,
          this.state.PassCount,
          this.state.PassAmount,
          this.state.amountPerPass,
          this.props.selectedPax
        );
      })
      .catch((error) => {
        this.setState({ PassAmount: "", amountPerPass: "" });
      });
  }

  inputValidation = () => {
    console.log("amount", this.state.PassAmount);
    if (this.state.PassType == "") {
      this.setState({ passTypeError: "*Required" });
      return false;
    }
    if (this.state.PassCount == "") {
      console.log("inside count");
      this.setState({ passCountError: "*Required" });
      return false;
    }
    if (this.state.PassValidity == "") {
      this.setState({ passValidityError: "*Required" });
      return false;
    }
    if (!parseInt(this.state.PassAmount) > 0) {
      this.setState({ passAmountError: "*Required" });
      return false;
    }
    if (!this.state.terms) {
      this.setState({ termsValidyError: "*Please accept Terms and Condition" });
      return false;
    }

    return true;
  };
}

Date.prototype.addMonths = function (m) {
  var d = new Date(this);
  var years = Math.floor(m / 12);
  var months = m - years * 12;
  if (years) d.setFullYear(d.getFullYear() + years);
  if (months) d.setMonth(d.getMonth() + months);
  return d;
};

const mapStateToProps = (state) => {
  console.log("mapStateToProps state", state);
  debugger;
  return {
    payload: state.juspay.payload,
    baseOrder: state.juspay.baseOrder,
    signature: state.juspay.signature,
    userData: state.login.userData,
    isLoggedIn: state.login.isLoggedIn,
    isLoading: state.login.isLoading,
    selectedPax: state.login.selectedPassenger,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onAddPayDetails: (
      PassType,
      PassValidity,
      PassCount,
      PassAmount,
      AmountPerPass,
      SelectedPax
    ) =>
      dispatch(
        loginActions.addPayDetails(
          PassType,
          PassValidity,
          PassCount,
          PassAmount,
          AmountPerPass,
          SelectedPax
        )
      ),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(AgentBuynowSec));
