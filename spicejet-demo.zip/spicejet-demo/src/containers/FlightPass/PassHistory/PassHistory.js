import React, { Component } from "react";
import Table from "react-bootstrap/Table";
import ExtraDetails from "./ExtraDetails/ExtraDetails";
import axios from "axios";
import { connect } from "react-redux";
import { withRouter } from "react-router";

import ReactTable from "react-table-6";
import "react-table-6/react-table.css";
import PropTypes from "prop-types";
import * as allUrls from "../../../Constants/Constants";

class PassHistory extends Component {
  constructor(props) {
    super(props);

    this.state = {
      columns: [
        {
          Header: "Flight Pass ID",
          accessor: "FlightPassID",
        },
        {
          Header: "Pass Type",
          accessor: "PassType",
        },
        {
          Header: "Total Flight Count",
          accessor: "TotalVoucherCount",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Status",
          accessor: "Status",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Valid Till",
          accessor: "ValidTill",
          sortable: false,
          filtarable: false,
        },
        {
          Header: "Validity",
          accessor: "validity",
          sortable: false,
          filtarable: false,
        },
      ],

      columnsLevelOne: [
        {
          Header: "Flight Count ID",
          accessor: "VoucherCode",
        },
        {
          Header: "Flight Count Amount",
          accessor: "VoucherAmount",
        },
        {
          Header: "PNR",
          accessor: "PNR",
        },
        {
          Header: "BookingDate",
          accessor: "BookingDate",
        },
        {
          Header: "ExpireDate",
          accessor: "ExpireDate",
        },
        {
          Header: "Status",
          accessor: "Status",
        },
      ],
      rowData: [],
    };
  }

  componentDidMount() {
    var url = allUrls.loadPassHistoryUrl + this.props.details.UserName;
    axios.get(url).then((res) => {
      this.setState({ rowData: res.data });
    });
  
   
  }
  filterCaseInsensitive(filter, row) {
    const id = filter.pivotId || filter.id;
    return row[id] != undefined
      ? String(row[id].toLowerCase()).startsWith(filter.value.toLowerCase())
      : true;
  }

  render() {
    return (
      <div
        className="ag-theme-alpine"
        style={{
          height: "auto",
          margin: "30px 0px",
        }}
      >
        <div className="card">
          <ReactTable
            data={this.state.rowData}
            columns={this.state.columns}
            filterable={true}
            sortable={true}
            defaultFilterMethod={this.filterCaseInsensitive}
            defaultPageSize={5}
            SubComponent={(row) => {
              return (
                <ReactTable
                  data={row.original.Vouchers}
                  columns={this.state.columnsLevelOne}
                  defaultPageSize={5}
                  defaultFilterMethod={this.filterCaseInsensitive}
                />
              );
            }}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    details: state.login.userData,
    isLoggedIn: state.login.isLoggedIn,
    tableData: state.login.tableData,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(PassHistory));
