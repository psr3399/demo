import React, {Component} from 'react'
import Plus from '../../../../assets/images/pp.png'
import Minus from '../../../../assets/images/mm.png'
import Auxiliary from '../../../../hoc/Auxiliary/Auxiliary'

class ExtraDetails extends Component {
    state={
        showDetails:true
    }
    
    toggleHandler = () => {
        const doesShow = this.state.showDetails
        this.setState({showDetails:!doesShow})
    }

    render() {
        return(
            <Auxiliary>
                
                {this.state.showDetails 
                ?
                <button style={{backgroundColor:'white',outline:'none',border:'none'}} onClick={this.toggleHandler}>
                    <img src={Plus} alt="no" />
                </button> 
                :
                <button style={{backgroundColor:'white',outline:'none',border:'none'}} onClick={this.toggleHandler}>
                    <img src={Minus} alt="no"/>
                </button>
                }
            </Auxiliary>
        )
    }
}

export default ExtraDetails