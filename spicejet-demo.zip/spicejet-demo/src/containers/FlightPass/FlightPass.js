import React, { Component } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import BuyPass from "./BuyPass/BuyPass";
import InfoPass from "./InfoPass/InfoPass";
import Auxiliary from "../../hoc/Auxiliary/Auxiliary";
import PassHistory from "../FlightPass/PassHistory/PassHistory";
import { withRouter } from "react-router";

class FlightPass extends Component {
  render() {
    return (
      <Auxiliary>
        <div className="container-fluid dullredbg">
          <div className="container">
            <div className="row">
              <div className="col-md-6 pt-5">
                <InfoPass />
              </div>
              <div className="col-md-6">
                <BuyPass />
              </div>
            </div>
          </div>
        </div>

        <Container style={{ marginTop: "3rem" }}>
          <Row>
            <Col>
              <h4 style={{ color: "#d7181f" }}>ORDERED PASS HISTORY</h4>
            </Col>
          </Row>
          <br />
          <Row>
            <Col>
              <PassHistory />
            </Col>
          </Row>
        </Container>
      </Auxiliary>
    );
  }
}

export default withRouter(FlightPass);
