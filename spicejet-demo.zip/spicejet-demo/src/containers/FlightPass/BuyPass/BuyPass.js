import React, { Component } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Auxiliary from "../../../hoc/Auxiliary/Auxiliary";
import Form from "react-bootstrap/Form";
import { button, Modal } from "react-bootstrap";
import styles from "./BuyPass.module.css";
import { withRouter } from "react-router";
import { connect } from "react-redux";
import * as JuspayActions from "../../../store/actions/index";
import NodeRSA from "node-rsa";
import axios from "axios";
import { date } from "yup";
import _ from "lodash";
import moment from "moment";
import * as allUrls from "../../../Constants/Constants";

class BuyPass extends Component {
  constructor(props) {
    super(props);
    this.handleIdProofType = this.handleIdProofType.bind(this);
    this.handleIdProof = this.handleIdProof.bind(this);
    this.handlePassType = this.handlePassType.bind(this);
    this.handleValidity = this.handleValidity.bind(this);
    this.handlePassCount = this.handlePassCount.bind(this);
    // this.handleAmount = this.handleAmount.bind(this);
    this.handleTermsCheck = this.handleTermsCheck.bind(this);
  }
  render() {
    let addPan = this.props.userData.PAN ? null : (
      <Auxiliary>
        <div className="col-md-6">
          <label>ID proof</label>
          <div className="inputBox">
            <select
              className="form-control form-control-sm"
              onChange={this.handleIdProofType}
              value={this.state.IdProofType}
            >
              <option value="">Select</option>
              <option value="PAN">PAN</option>
              <option value="Passport">Passport</option>
            </select>
            <small style={{ color: "white" }}>
              {this.state.IdProofTypeError}
            </small>
          </div>
        </div>
        <div className="col-md-6">
          <label>Passport / PAN NO.:</label>
          <div className="inputBox">
            <input
              type="text"
              name="Traveller"
              className="input"
              placeholder="GOVT ID"
              onChange={this.handleIdProof}
              value={this.state.IdProof}
            />
            <div className="buypasserr">
              <small style={{ color: "white" }}>
                {this.state.IdProofError}
              </small>
            </div>
          </div>
        </div>
      </Auxiliary>
    );

    return (
      <Auxiliary>
        <div className="searchbox text-uppercase">
          <p>Buy New Flight Pass</p>
          <form className="searchalign buyoption">
            <div className="row">
              {addPan}
              <div className="col-md-6">
                <label>Choose Pass Type</label>
                <div className="inputBox">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handlePassType}
                  >
                    <option value="">Select</option>
                    <option value="Short Haul">Short Haul</option>
                    <option value="All Flights" selected>
                      All Flights
                    </option>

                    {/* <option value="Long Haul">Long Haul</option> */}
                  </select>
                  <div className="buypasserr">
                    <small style={{ color: "white" }}>
                      {this.state.passTypeError}
                    </small>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <label>Choose Validity</label>
                <div className="inputBox">
                  <select
                    className="form-control form-control-sm"
                    onChange={this.handleValidity}
                    value={this.state.PassValidity}
                  >
                    <option value="">Select</option>
                    <option value="3">3 Months</option>
                    <option value="6">6 Months</option>
                    <option value="12">12 Months</option>
                  </select>
                  <div className="buypasserr">
                    <small style={{ color: "white" }}>
                      {this.state.passValidityError}
                    </small>
                  </div>
                </div>
              </div>
              <div className="col-md-6" onChange={this.handlePassCount}>
                <label className="text-uppercase">Choose No. of Flights</label>
                <div className="inputBox">
                  <select
                    className="form-control form-control-sm"
                    value={this.state.PassCount}
                  >
                    {this.state.PassCountListBaseDynamic.map((team) => (
                      <option key={team.value} value={team.value}>
                        {team.display}
                      </option>
                    ))}
                    {/* <option value="">Select</option>
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option> */}
                  </select>
                  <div className="buypasserr">
                    <small style={{ color: "white" }}>
                      {this.state.passCountError}
                    </small>
                  </div>
                </div>
              </div>

              <div className="col-md-6">
                <label>Amount</label>
                <div className="">
                  <input
                    type="text"
                    className="input buyamt"
                    value={this.state.PassAmount}
                    onChange={this.handleAmount}
                    disabled={true}
                  />

                  <small className="text-white">
                    [ Per flight price :
                    <strong> {this.state.PerFlightIdAmount}</strong> ]
                  </small>
                  <div className="buypasserr">
                    <small style={{ color: "white" }}>
                      {this.state.passAmountError}
                    </small>
                  </div>
                </div>
              </div>
            </div>

            <div className="row">
              <div className="buypassagreement">
                <input
                  type="checkbox"
                  name="is_name"
                  value={this.state.terms}
                  onChange={this.handleTermsCheck}
                />
                <label className="check ">
                  I have read and agree to the{" "}
                  <span class="text-warning" onClick={() => this.tncModal()}>
                    Terms &amp; Conditions
                  </span>{" "}
                  and Privacy Policy
                  <div className="buypasserrtnc">
                    <small style={{ color: "white" }}>
                      {this.state.termsValidyError}
                    </small>
                  </div>
                </label>
              </div>
              <button
                type="button"
                className="btn btn-light searchbtn"
                onClick={this.onSubmit}
              >
                BUY NOW
              </button>
            </div>
          </form>
        </div>

        {/* T&C Modal popup */}

        <Modal
          size="md"
          className="modal fade"
          onHide={this.closetnc}
          show={this.state.tncshow}
        >
          <Modal.Header closeButton className="modal-header modalheader">
            <h2 className="modal-title  text-center" id="exampleModalLongTitle">
              Term &amp; Conditions{" "}
            </h2>
          </Modal.Header>
          <Modal.Body className="modal-body pl-5 pr-5 text-center">
            <p> lorem </p>
          </Modal.Body>
        </Modal>
      </Auxiliary>
    );
  }
  state = {
    IdProofTypeError: "",
    IdProofError: "",
    IdProofType: "",
    IdProof: "",
    payload: {},
    baseOrder: {},
    signature: "",
    PassType: "All Flights",
    PassValidity: "",
    PassCount: "",
    PassAmount: "",
    terms: false,
    entrypointid: "main",
    action: "payment_page",
    merchantId: "websiteuser",
    clientId: "websiteuser_web",
    merchantKeyId: "3388",
    environment: "sandbox",
    orderID: Date.now().toString(),
    first_name: this.props.userData.Title,
    last_name: this.props.userData.FullName,
    mobileNumber: this.props.userData.UserName,
    emailAddress: this.props.userData.EmailID,
    customerId: this.props.userData.UserName,
    passTypeError: "",
    passCountError: "",
    passValidityError: "",
    passAmountError: "",
    termsValidyError: "",
    amountPerPass: "",
    tncshow: false,
    PassCountListBase: [
      { value: "", display: "Select" },
      { value: "5", display: "5" },
      { value: "10", display: "10" },
      { value: "25", display: "25" },
      { value: "50", display: "50" },
      { value: "100", display: "100" },
    ],
    PassCountListBaseDynamic: [
      { value: "", display: "Select" },
      { value: "5", display: "5" },
      { value: "10", display: "10" },
      { value: "25", display: "25" },
      { value: "50", display: "50" },
      { value: "100", display: "100" },
    ],
    PerFlightIdAmount: "",
  };

  tncModal() {
    this.setState({ tncshow: true });
  }
  closetnc = () => {
    this.setState({ tncshow: false });
  };

  handleIdProofType(e) {
    console.log("handleIdProofType", e.target.value);
    this.setState({ IdProofType: e.target.value });
  }
  handleIdProof(e) {
    console.log("handleIdProof", e.target.value);
    this.setState({ IdProof: e.target.value });
  }
  handleTermsCheck(e) {
    var termsVal = !this.state.terms;
    this.setState({ terms: termsVal });
  }
  handlePassType(e) {
    console.log("handlePassType", e.target.value);
    this.setState({
      PassType: e.target.value,
      PassValidity: "",
      PassCount: "",
      PassAmount: "",
    });
  }
  handleValidity(e) {
    let validity = e.target.value;
    console.log("handleValidity", e.target.value);
    console.log("Current DAte ", moment());
    console.log("Expiry DAte ", moment().add(validity, "M"));
    if (validity == 3) {
      this.state.PassCountListBaseDynamic = _.filter(
        this.state.PassCountListBase,
        (v) => v.value <= 25
      ); // ['hello']this.state.PassCountListBase;
      this.setState({
        PassValidity: e.target.value,
        PassCount: "",
        PassAmount: "",
      });
    } else {
      this.state.PassCountListBaseDynamic = this.state.PassCountListBase;
      this.setState({
        PassValidity: e.target.value,
        PassCount: "",
        PassAmount: "",
      });
    }
    console.log("PassCount", this.state.PassCount);
  }
  handlePassCount(e) {
    console.log("handlePassCount", e.target.value);
    this.setState({ PassCount: e.target.value });
    var buypassData = {
      PassType: this.state.PassType,
      Months: this.state.PassValidity,
      Coupons: e.target.value,
      Amount: 0,
    };

    axios
      .post(allUrls.getBuyPassAmount, buypassData)
      .then((res) => {
        console.log("getamount", res.data);
        this.setState({
          amountPerPass: res.data.Amount.toFixed(2),
        });
        this.setState({
          PassAmount: (res.data.Amount * this.state.PassCount).toFixed(2),
          PerFlightIdAmount: res.data.Amount,
        });
      })
      .catch((error) => {
        this.setState({
          PassAmount: "",
        });
      });
  }
  // handleAmount(e) {
  //   console.log("handleAmount", e.target.value);
  //   this.setState({ PassAmount: e.target.value });
  // }

  inputValidation = () => {
    console.log("amount", this.state.PassAmount);
    let addPan = this.props.userData.PAN;
    if (addPan == "") {
      if (this.state.IdProofType == "") {
        this.setState({ IdProofTypeError: "*Required" });
        return false;
      }
      if (this.state.IdProof == "") {
        this.setState({ IdProofError: "*Required" });
        return false;
      } else if (
        this.state.IdProofType == "PAN" &&
        !/[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/.test(this.state.IdProof)
      ) {
        this.setState({ IdProofError: "Wrong PAN id" });
        return false;
      } else if (
        this.state.IdProofType == "Passport" &&
        !/[0-9]$/.test(this.state.IdProof)
      ) {
        this.setState({ IdProofError: "Wrong Passport no." });
        return false;
      }
    }
    if (this.state.PassType == "") {
      this.setState({ passTypeError: "*Required" });
      return false;
    }
    if (this.state.PassValidity == "") {
      this.setState({ passValidityError: "*Required", PassCount: "" });
      return false;
    }
    if (this.state.PassCount == "") {
      console.log("inside count");
      this.setState({ passCountError: "*Required" });
      return false;
    }

    if (!parseInt(this.state.PassAmount) > 0) {
      this.setState({ passAmountError: "*Required" });
      return false;
    }
    if (!this.state.terms) {
      this.setState({ termsValidyError: "*Please accept Terms and Condition" });
      return false;
    }

    return true;
  };

  onSubmit = () => {
    this.setState({
      passAmountError: "",
      passCountError: "",
      passTypeError: "",
      passValidityError: "",
      IdProofError: "",
      IdProofTypeError: "",
    });
    console.log("initiated juspay");
    const isFormValid = this.inputValidation();
    if (isFormValid) {
      console.log("inside form valid  ");
      let addPan = this.props.userData.PAN;
      if (addPan == "") {
        let pancardData = {
          DocumentType: this.state.IdProofType == "PAN" ? "PC" : "P",
          CustomerID: this.props.userData.UserName,
          DocumentNumber: this.state.IdProof,
          IssuedDate: "10/10/2012",
          Gender: "male",
        };
        axios
          .post(allUrls.insertCustomerTravelDocUrl, pancardData)
          .then((res) => {});
      }
      // this.state.payload.amount = this.state.PassAmount;
      // this.state.baseOrder.amount = this.state.PassAmount;
      this.baseOrder = {
        order_id: this.state.orderID,
        timestamp: this.state.orderID,
        first_name: this.state.first_name,
        last_name: this.state.last_name,
        amount: this.state.PassAmount,
        customer_id: this.state.customerId,
        customer_phone: this.state.customerId,
        customer_email: this.state.emailAddress,
        merchant_id: this.state.merchantId,
        return_url: allUrls.returnUrlBuyPass,
        //return_url: "http://10.218.31.215:8000/JusPayResponse",
      };
      console.log("enter in orders ");
      //const payload = JSON.stringify(this.baseOrder); //new Order(JSON.stringify(baseOrder));
      const pay = JSON.stringify(this.baseOrder);
      //console.log("order info:" + payload);
      const encyptKey = new NodeRSA(
        "-----BEGIN RSA PRIVATE KEY-----MIIEpQIBAAKCAQEA2R+5+b1HZSNNMotnr7Z/5By4NSTZW4dDMGDy2huOSLn1EF6v75sssdY5kRkFoihLIeNQA+yzsi0kzpz3rCCCmo1DJwgoqA48JVQwwBjZ9SHeC0nE66VODmMJJGNWe1quHWQb3otIzS+U+rtd1Alzo9up8u8e+FrecyjO6fBMZfd32iO7qPtExtA1XDtKMqoRbHMiAz940xA5+BLmJC+gp1IYsVce2KA5BW1laPxbku42aQR7eZipSa3BYRY8m964Aj6vLj4kTeTbrc4OH7yatRdWbVbrwVWpg936g8Q3Qf3jQY+HMu76l1WeXK4GkPkA+oJXY6ag1XhhqtOrLw3rJwIDAQABAoIBAQCjy2thG4lgouD54HC3/dU9IO1WKhZPFht5w6lxIJiWBLL7RnMzLrzo69NBwr6dNgh36CPU0hw9rhC2TXQKRfxA25BtQZpqLVLyVjDwuc6zPnljyqLjojDgaZXb/ZSgOihfw8XCfRDOubaJ8A84hmjWlEABJKMYeHSYK5Dsqnr37/Oj4OT2NWLaRx8Kk0HPuv/bxx3MHurIHRtG514UJZcOfN8Ti69/DoYbtb/Mpg/djXr5s47TafxPa8jyT2E8nWboPvYPDQcdu2CIE0mbrj2C0Ak7g20ZYzm9HCbJHVG+2rPSjVgXKW2ZgXoZflte+G5vRfDrZH+TZuo+ja0pVlIBAoGBAP4ZEtdpRJp5kvj7bUIkXd5E6lrxd2M0VprfMhHk0i+Z1p1nF8StF6p9uIGuRIEthvdRZVy56fWCHXOfmquRJDHazQZVnnXcRaqhuMYdZoJ3i1KkmSL4X/SdBsB4rY4FQZWNtwKoSeDugQeJzf4bhyn0iZGbWPq+XO70MxXya8CfAoGBANq/zL6ul+G6i/nXrfzwUr83EtXh6Zoj51YBK4g3ZIIuWkWvbo9NguV3p9KmeRKMWwYORHC7aVwpHdjzOyzmSFdmC+5dqVe6rkdl9AzxpKt0p0rOznmZUhDcdElCk0p6pC5RQDAt2PA4aR3kT+9z2dPV0IHsUGiouF/LtmTmdCB5AoGAIShUdRefhCjpLORiVYc5WI/VpRhtY9yokH0fo4Ygh2Wjw9Z4G4oa1HyjXwjGl7TBL/THLVp1VTwta7EgFdNSzc6ngnQZwXeE/8cqvW+IuO2wmJAyC4Ytv1XeU69rtmSpMkLT5tzfByMYY0twPgCJmsf2S7Hh4paEugnTwMFpnjECgYEAoTqc/i5RY97LLOr7ImM/mhBNobdRJnswFwPlwhCR1CG2B4a2Rokq4VbAK1LoCfPJYz1A1JZNoc/sX+tmwkE5MLHWOWpvVmoR6i4LIz83z+e7JjgnlxialDLowtZ/GXYrbLgWR2yDaQsq7w1InYUWGDyP4jL7USiKPJE5bkUtcoECgYEAwhbb1NxzteIr8zlytMj52sgeiJPQRjbU5CoMAJuiHvYHT8jQwso7lfbz+fXdQamU29v1Hdhc2JR1xWxrTz4bAt1l9lWK8zQBTK3SOlhyvrvNkKtTwjansR6+uwB9KY5mrF++pRA8IL2f0yhx2uqwDkX/Og6ZnFHJn3BvQM/DWPg=-----END RSA PRIVATE KEY-----"
      );
      const result = encyptKey.sign(pay, "base64", "utf8");
      //res.json({ message: result });
      console.log("singg", result);
      this.setState({ signature: result });

      this.payload = {
        action: this.state.action,
        merchantId: this.state.merchantId,
        orderId: this.state.orderID,
        amount: this.state.PassAmount,
        customerId: this.state.customerId,
        endUrls: this.baseOrder.return_url,
        orderDetails: JSON.stringify(this.baseOrder),
        environment: this.state.environment,
        merchantKeyId: this.state.merchantKeyId,
        client_id: this.state.clientId,
        entry_point_id: this.state.entrypointid, //Iframe will load inside div with id='main'
        signature: result,
      };

      // this.setState({ payload: this.payload });
      // this.setState({ baseOrder: this.baseOrder });
      // this.setState({ signature: this.state.signature });
      this.props.onRequest(this.payload, this.baseOrder, result);
      debugger;
      this.currentDate = new Date();
      this.FPVouchersReqData = {
        CustomerID: this.state.customerId,
        PassType: this.state.PassType,
        ValidityMonths: this.state.PassValidity,
        Coupons: this.state.PassCount,
        Amount: this.state.amountPerPass,
        Leaflet_ID: 0,
        CustomerName: this.props.userData.FullName,
        MobileNumber: this.state.customerId,
        EmailAddress: this.state.emailAddress,
        PAN: this.props.userData.PAN,
        PurchaseDate: new Date(),
        ExpireDate: moment().add(this.state.PassValidity, "M"),
        Status: 0,
        Title: this.props.userData.Title,
        ProofType: "PAN",
        DOB: this.props.userData.DOB,
        TransactionID: this.state.orderID,
        Remarks: "",
        AdditionalInfo: "",
        CreatedBy: this.state.customerId,
      };
      window.localStorage.setItem(
        "FPVouchersReqData",
        JSON.stringify(this.FPVouchersReqData)
      );
      this.props.history.push({
        pathname: "/JusPayRequest",
      });
    }

    //console.log("privateKeyHyperBeta", this.privateKeyHyperBeta);
    //console.log("payload", this.payload);
    //console.log("baseOrder", this.baseOrder);
    // console.log("payload", this.state.payload);
    // console.log("baseOrder", this.state.baseOrder);
  };

  componentDidMount() {}
}

Date.prototype.addMonths = function (m) {
  var d = new Date(this);
  var years = Math.floor(m / 12);
  var months = m - years * 12;
  if (years) d.setFullYear(d.getFullYear() + years);
  if (months) d.setMonth(d.getMonth() + months);
  return d;
};

const mapStateToProps = (state) => {
  console.log("mapStateToProps state", state);
  return {
    payload: state.juspay.payload,
    baseOrder: state.juspay.baseOrder,
    signature: state.juspay.signature,
    userData: state.login.userData,
    isLoggedIn: state.login.isLoggedIn,
    isLoading: state.login.isLoading,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    onRequest: (payload, baseOrder, signature) =>
      dispatch(JuspayActions.onJusPayRequest(payload, baseOrder, signature)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(BuyPass));
