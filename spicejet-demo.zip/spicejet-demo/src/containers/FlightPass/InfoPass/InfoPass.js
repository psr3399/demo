import React, { Component } from "react";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Auxiliary from "../../../hoc/Auxiliary/Auxiliary";
import Profile from "../../../assets/images/profile.png";
import { connect } from "react-redux";
import { withRouter } from "react-router";
import { Redirect } from "react-router-dom";

class InfoPass extends Component {
  componentDidMount = () => {
    if (!this.props.isLoggedIn) {
      this.props.history.push("/");
    }
  };
  componentDidUpdate = () => {
    if (this.props.match.path !== "/") {
      if (!this.props.isLoggedIn) {
        this.props.history.push("/");
      }
    }
  };

  render() {
    // console.log('hello! i am inside infoPass.js too much data is here SAVE ME!!',this.props.tableData)
    // console.log('inifopass',this.props.isLoggedIn)
    return (
      <Auxiliary>
        <div className="container">
          <div className="row">
            <div className="col-md-12 pt-5">
              <div className="row">
                <div className="col-md-3">
                  <span className="accountimg">
                    <i className="fa fa-user-circle-o"></i>
                  </span>
                </div>
                <div className="col-md-9">
                  <h4 style={{ textTransform: "uppercase" }}>
                    {this.props.details.Title}.{this.props.details.FullName}
                  </h4>
                  <div className="col pl-0 mt-3">
                    <p>Mobile Number: {this.props.details.UserName}</p>
                  </div>
                  <div className="col pl-0">
                    <p>Email Address: {this.props.details.EmailID}</p>
                  </div>
                  {/* <div className="col pl-0">
                    <p>DOB: {this.props.details.DOB}</p>
                  </div> */}
                  <div className="col pl-0">
                    <p>PAN: {this.props.details.PAN}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Auxiliary>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    details: state.login.userData,
    isLoggedIn: state.login.isLoggedIn,
    tableData: state.login.tableData,
  };
};

const mapDispatchToProps = (dispatch) => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(InfoPass));
