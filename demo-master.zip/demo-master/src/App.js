import React from 'react';
import Footer from './Components/Footer';
import Header from './Components/Header';
import Registration from './Components/Registration';

function App() {
  return (
    <div>
      <Header />
      <Registration />
      <Footer />
    </div>
  );
}

export default App;
