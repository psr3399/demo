import React from 'react';
// import { PDFViewer } from '@react-pdf/renderer';
import { PDFDownloadLink, Document, Page } from '@react-pdf/renderer'; 
import MyDocument from './Mydocument';

const App = () => (
  <div>
    <PDFDownloadLink document={<MyDocument />} fileName="sample.pdf">
      {({ blob, url, loading, error }) => (loading ? 'Loading document...' : 'Download now!')}
    </PDFDownloadLink>
  </div>
)

// const App = () => (
//   <PDFViewer>
//     <MyDocument />
//   </PDFViewer>
// );

export default App;
