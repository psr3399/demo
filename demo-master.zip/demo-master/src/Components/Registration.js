import {
  withFormik,
  FormikProps,
  Formik,
  Field,
  Form,
  ErrorMessage,
} from "formik";
import { withRouter } from "react-router";
import { button, Modal } from "react-bootstrap";
import moment from "moment";
import React, { Component } from "react";
import axios from "axios";

const initialValues = {
  title: "Mr",
  firstName: "",
  lastName: "",
  id: "PAN",
  idnum: "",
  date: new Date(),
  mobile: "",
  email: "",
  pass1: "",
  pass2: "",
  terms: false,
};

class Registration extends Component {
  constructor() {
    super();

    this.state = {
      show: false,
      userOtp: "",
      setValues: {},
      isOtpValid: false,
      otpError: "",
      minutes: "",
      seconds: "",
      buttonDisable: false,
      maxdate: moment().add(-18, "year").format("YYYY-MM-DD"),
      mindate: moment().add(-100, "year").format("YYYY-MM-DD"),
      tncshow: false,
    };
  }

  tncModal() {
    this.setState({ tncshow: true });
  }
  closetnc = () => {
    this.setState({ tncshow: false });
  };
  onOtpChange = (event) => {
    this.setState({ userOtp: event.target.value });
  };

  checkValidtyHandler = () => {
  };

  callbackFunction = (min, sec) => {
    if (this.state.show) {
      if (min == 0 && sec == 0) {
        this.setState({ buttonDisable: true });
      } else {
        this.setState({ buttonDisable: false });
      }
    }
  };

  componentDidUpdate = () => {
  };

  buttonDisableHandler = () => {
  };
  render() {
    console.log(this.state.setValues);
    return (
      <Formik
        initialValues={initialValues}
        onSubmit={(values) => {
          const SendOTPSCData = {
            mobilenumber: values.mobile,
            emailaddress: "",
            CardHolderName: "",
          };

          // .then(res=>console.log(res.data))
          console.log("post request sent");
          const showStore = !this.state.show;
          this.setState({ show: showStore, setValues: values });
          this.buttonDisableHandler();
        }}
      >
        {(formik) => (
          <div className="container mb-5">
            <div className="registrationPage mainBackground mainBanner">
              <div className="registrationWrapper">
                <div className="introducingbackground">
                  <div className="introducingCol">
                    <h3 className="introducingTitle">Introducing</h3>
                    <div className="spiceClubLogo"></div>
                    <h3 className="introducingTitle2">
                      <strong>FLIGHT PASS</strong>
                    </h3>
                    <p className="descMain"></p>
                    <p className="descSub">Purchase Now and Get:</p>
                    <div className="benefitList">
                      <div className="leftSec">
                        <ul>
                          <li>Convenience fee: &#x20B9; 0</li>
                          <li>50% off on SpiceMax</li>
                          <li>50% off on Meals & Seats</li>
                          <li>Extra saving in your travel budgets</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="formCol">
                  <h3 class="formTitle mb-5">Flight Pass Registration</h3>
                  <Form>
                    <div className="usernameSection row">
                      <div className="userTitle col-md-4">
                        <label>Title</label>
                        <Field
                          as="select"
                          className="form-control titleInputField"
                          name="title"
                          id="title"
                        >
                          <option value="Mr">Mr</option>
                          <option value="Ms">Ms</option>
                          <option value="Mrs">Mrs</option>
                        </Field>
                      </div>
                      <div className="userName col-md-4">
                        <label>Name ( as per Govt. ID )</label>
                        <Field
                          type="text"
                          className="form-control usernameField regisInput isEmpty transitForm"
                          placeholder="Your First Name"
                          name="firstName"
                          id="firstName "
                          onChange={(e) => {
                            e.preventDefault();
                            const { value } = e.target;
                            let strValue = value.toString();
                            strValue = strValue.replace(/[^A-Za-z]/gi, "");
                            formik.setFieldValue("firstName", strValue);
                          }}
                        />
                        <ErrorMessage name="firstName">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="lastnameSection lastnamealign  col-md-4">
                        <label></label>
                        <Field
                          id="lastName"
                          type="text"
                          className="form-control lastnameField regisInput isEmpty transitForm"
                          placeholder="Your Last Name"
                          name="lastName"
                          onChange={(e) => {
                            e.preventDefault();
                            const { value } = e.target;
                            let strValue2 = value.toString();
                            strValue2 = strValue2.replace(/[^A-Za-z]/gi, "");
                            formik.setFieldValue("lastName", strValue2);
                          }}
                        />
                        <ErrorMessage name="lastName">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>
                    <div className="usernameSection row mt-4">
                      <div className="userTitle  col-md-4">
                        <label>Your ID proof</label>
                        <Field
                          as="select"
                          className="form-control titleInputField"
                          name="id"
                          id="id"
                        >
                          <option value="PAN">PAN</option>
                          <option value="Passport">Passport</option>
                        </Field>
                      </div>
                      <div className="userName  col-md-4">
                        <label>Govt. ID card no.</label>
                        <Field
                          id="idnum"
                          type="text"
                          className="form-control usernameField regisInput isEmpty transitForm"
                          placeholder="Passport/Pan No."
                          name="idnum"
                        />
                        <ErrorMessage name="idnum">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="lastnameSection  col-md-4">
                        <label2>Date of Birth ( as per Govt. ID )</label2>

                        <input
                          type="date"
                          className="form-control dobField regisInput isEmpty"
                          name="date"
                          maxLength="8"
                          value={formik.values.date}
                          min={this.state.mindate}
                          max={this.state.maxdate}
                          onKeyDown={(e) => e.preventDefault()}
                          onChange={formik.handleChange}
                        />
                        <ErrorMessage name="date">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>
                    <div className="phoneSec row">
                      <div className="col-md-12">
                        <label>
                          Your Contact Details ( Mobile Number would become your
                          Member ID )
                        </label>
                      </div>
                      <div className="col-md-4 scloginform">
                        <label> Mobile Number* </label>
                        {/* <PhoneInput
                          id="mobile"
                          name="mobile"
                          country={"in"}
                          onlyCountries={["in"]}
                          value={formik.values.mobile}
                          onBlur={formik.setFieldTouched}
                          onChange={(value) => {
                            formik.setFieldValue("mobile", value, true);
                          }}
                        /> */}
                        <ErrorMessage name="mobile">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <div className="col-md-4">
                        <label>Email ID* </label>
                        <Field
                          id="email"
                          type="email"
                          className="form-control regisInput emailField isEmpty transitForm"
                          placeholder="Email Address"
                          name="email"
                        />
                        <p className="registrationEmailError">
                          *Please enter a valid email address
                        </p>
                        <ErrorMessage name="email">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                    </div>

                    <div className="passwordSection row">
                      <div className="col-md-12">
                        <label className="popover__wrapper">
                          Set Password <span className="passwordInfo"></span>
                          <div className="popover__content">
                            <p>
                              Password must be AlphaNumeric and must contain
                              atleast one special character(@#$%&) and minimum 8
                              characters length
                            </p>
                            {/* <p>Password must be alpha numeric </p>
                            <p>
                              Be a minimum of 8 characters in length and maximum
                              of 16 characters
                            </p>
                            <p>
                              Must contain at least one special character from
                              the following categories &@#$%{" "}
                            </p> */}
                          </div>
                        </label>
                      </div>
                      <div className="col-md-4">
                        <Field
                          type="password"
                          className="passwordField regisInput form-control"
                          placeholder="Enter Password"
                          name="pass1"
                          id="pass1"
                        />
                        <ErrorMessage name="pass1">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <div className="col-md-4">
                        <Field
                          id="pass2"
                          type="password"
                          className="confirmPasswordField regisInput form-control"
                          placeholder="Retype Password"
                          name="pass2"
                        />
                        <ErrorMessage name="pass2">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>

                      <div className="col-md-12 mt-4">
                        <Field type="checkbox" id="terms" name="terms" />
                        {/* <span className="checkmark"></span> */}
                        <label id="checkboxLabel" className="registrationPage ">
                          I agree to register as a member by accepting the{" "}
                          <span
                            class="text-danger"
                            onClick={() => this.tncModal()}
                          >
                            Terms and Conditions
                          </span>{" "}
                          of SpiceClub
                          <br />
                        </label>
                        <ErrorMessage name="terms">
                          {(errMsg) => (
                            <small style={{ color: "red" }}>{errMsg}</small>
                          )}
                        </ErrorMessage>
                      </div>
                      <button type="submit" className="signUp ml-3">
                        Registration
                      </button>
                    </div>
                  </Form>
                </div>
                <Modal size="sm" className="modal fade" show={this.state.show}>
                  <Modal.Header className="modal-header modalheader d-block">
                    <h2
                      className="modal-title  text-center"
                      id="exampleModalLongTitle"
                    >
                      OTP{" "}
                    </h2>
                  </Modal.Header>
                  <Modal.Body className="modal-body pl-5 pr-5 text-center">
                    <label>
                      <strong>Enter One Time Password</strong>
                    </label>
                    <div
                      className="inputBox1"
                      style={{ marginBottom: "10px !important" }}
                    >
                      <input
                        type="text"
                        name="Traveller"
                        className="input"
                        pattern="[0-9]*"
                        maxLength="6"
                        placeholder="Enter OTP"
                        onChange={this.onOtpChange}
                      />
                    </div>
                    <div className="mb-1">
                      {this.state.isOtpValid ? (
                        <small style={{ color: "red", marginTop: "-20px" }}>
                          {this.state.otpError}
                        </small>
                      ) : null}
                    </div>
                    <button
                      className="btn btn-danger"
                      onClick={this.checkValidtyHandler}
                      disabled={this.state.buttonDisable}
                    >
                      Confirm
                    </button>
                    <p className="pt-3">{/* <timer></timer> */}</p>
                    {/* <Timer
                      parentCallback={this.callbackFunction}
                      mobile={this.state.setValues.mobile}
                    /> */}
                  </Modal.Body>
                </Modal>

                {/* T&C Modal popup */}

                <Modal
                  size="md"
                  className="modal fade"
                  onHide={this.closetnc}
                  show={this.state.tncshow}
                >
                  <Modal.Header
                    closeButton
                    className="modal-header modalheader"
                  >
                    <h2
                      className="modal-title  text-center"
                      id="exampleModalLongTitle"
                    >
                      Term &amp; Conditions{" "}
                    </h2>
                  </Modal.Header>
                  <Modal.Body className="modal-body pl-5 pr-5 text-center">
                    <p> lorem </p>
                  </Modal.Body>
                </Modal>
              </div>
            </div>
          </div>
        )}
      </Formik>
    );
  }
}

export default Registration;
