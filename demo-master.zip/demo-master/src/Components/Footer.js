import React from "react";
import gplay from "./../assets/images/gplay.png";
import appstore from "./../assets/images/appstore.png";
import "../../src/assets/css/Footer.scss";

const Footer = (props) => {
  return (
    <footer className="mainfooter" role="contentinfo">
      <div className="footer-middle">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-6 col-sm-6 redbg p-5">
              <div className="footer-pad">
                <h4>DOWNLOAD THE MOBILE APP</h4>
                <p>
                  Lorem ipsum dolor sit amet consectetur adipisicing elit.
                  Dolorem officiis soluta iusto accusamus ex illum dolor.
                </p>
                <span>
                  <img src={gplay} alt="no" className="img-fluid" />
                </span>
                <span>
                  <img src={appstore} alt="no" className="img-fluid" />
                </span>
              </div>
            </div>
            <div className="col-md-6 blackbg p-5">
              <div className="row">
                <div className="col-md-6">
                  <p>Talk to us: +91 981 179 5555 (24 X 7)</p>
                  <p>
                    <a href="mailto:spiceclub@spicejet.com">
                      Write to us: spiceclub@spicejet.com
                    </a>
                  </p>
                </div>
                <div className="col-md-6">
                  <h4>Follow Us</h4>
                  <ul className="social-network social-circle">
                    <li>
                      <a href="#" title="Facebook">
                        <i className="fa fa-facebook"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#" title="Linkedin">
                        <i className="fa fa-linkedin"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#" title="Linkedin">
                        <i className="fa fa-twitter"></i>
                      </a>
                    </li>
                    <li>
                      <a href="#" title="Linkedin">
                        <i className="fa fa-youtube"></i>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>

              <p className="text-center pt-4">
                &copy; Copyright 2020 - Spicejet india. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;